﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgentClasses;

namespace WaterDemandAgentClass
{
    public class WaterDemandAgent : Agent
    {

        protected double FIndoorDemand = 0.0;
        protected double FOutdoorDemand = 0.0;
        protected double FProcessDemand = 0.0;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="aTypeCode">    The type code. </param>
        /// <param name="aTypeLabel">   The type label. </param>
        ///-------------------------------------------------------------------------------------------------

        public WaterDemandAgent(string aTypeCode, string aTypeLabel): base (aTypeCode, aTypeLabel)
        {
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="aTypeCode">    The type code. </param>
        /// <param name="aTypeLabel">   The type label. </param>
        /// <param name="aName">        The name. This must be a unique name for all agents used</param>
        ///-------------------------------------------------------------------------------------------------

        public WaterDemandAgent(string aTypeCode, string aTypeLabel, string aName) : base(aTypeCode,aTypeLabel,aName)
        {
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the indoor demand. </summary>
        ///
        /// <value> The indoor demand. </value>
        ///-------------------------------------------------------------------------------------------------

        public double IndoorDemand 
        {
            get { return FIndoorDemand; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the outdoor demand. </summary>
        ///
        /// <value> The outdoor demand. </value>
        ///-------------------------------------------------------------------------------------------------

        public double OutdoorDemand
        {
            get { return FOutdoorDemand; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the process demand. </summary>
        ///
        /// <value> The process demand. </value>
        ///-------------------------------------------------------------------------------------------------

        public double ProcessDemand
        {
            get { return FProcessDemand; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total demand. </summary>
        ///
        /// <value> The total number of demand. </value>
        ///-------------------------------------------------------------------------------------------------

        public double TotalDemand
        {
            get { return FIndoorDemand + FOutdoorDemand + FProcessDemand; }
        }


        /// <summary>   Estimate demand. </summary>
        public virtual void EstimateDemand()
        {

        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Runs this object. </summary>
        ///
        /// <returns>   true if it succeeds, false if it fails. </returns>
        ///
        /// <seealso cref="AgentClasses.Agent.Run()"/>
        ///-------------------------------------------------------------------------------------------------

        public override bool Run()
        {
            EstimateDemand();
            return base.Run();
        }

        public virtual string ToString(string Format)
        {
            string result = FName;
            // Setup Formatting
            Format = Format.ToUpper();
            string Mark = "";
            switch (Format)
            {
                case "CSV":
                    Mark = ",";
                    break;
                case "TAB":
                    Mark = "/t";
                    break;
            }
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }
            string DemandStr = TotalDemand.ToString();
            string IndoorStr = IndoorDemand.ToString();
            string OutdoorStr = OutdoorDemand.ToString();
            string ProcessStr = ProcessDemand.ToString();
            result += Mark + DemandStr + Mark + IndoorStr + Mark + OutdoorStr + Mark + ProcessStr;
            return result;
        }
    }
}
