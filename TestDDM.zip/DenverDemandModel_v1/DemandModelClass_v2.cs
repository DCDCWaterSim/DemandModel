﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using UniDB;
using AgentClasses;

//===================================================================
// Denver Demand Model
// Version 1.0   3/3/17
// A model that estimates residential demand for different residential building types.
// Keeper:  Ray Quay 3/3/17
//          Decision Center for a Desert City
//          Arizona State University
// Based on the Pop_And_Product_Type_Model_DRAFT.xlms Excel weorkbook developed by Mitch Hollis from Denver Water 
// provide to DCDC on Feb 10th 2017
//
// Notes:
// Version 1
// The documentation here in refers to the cell ID for different cells.  In all cases, unless other wise specified, these cell references refer 
// to the Population & Product Type Model worksheet
//
// ===========================================================================

namespace DenverDemandModel
{
    /// <summary>   Building demand data. </summary>
    public class BuildingDemandData
    {

        // CONSTANTS
        const double BADVALUE = double.NaN;

        // DataTable
        DataTable FBuildingData;

        // Column Info
        const int BFieldCount = 18;

        int BTypeCode = 0;     // Building Type Code
        int BType = 1;          // Building Type
        int PPHH = 2;           // Persons Per Household
        int IGPCD = 3;          // Default Indoor Gallons Per Capita per Day
        int DUA = 4;            // Default Dweling Units Per Acre
        int SGPSF = 5;          // Default Seasonal Gallons Per SqFt Pervious Surface
        int DummyInt = 6;       // Slope Intercept for pervious surface function
        int DummyExp = 7;       // Exponent for pervious surface function
        int DefaultPOP = 8;     // Default population
        int IGPCD_Hi = 9;       // High end of Indoor Gallons Per Capita per Day
        int IGPCD_Mn = 10;       // Mean or Median of Indoor Gallons Per Capita per Day
        int IGPCD_Lo = 11;       // Low end of Indoor Gallons Per Capita per Day
        int DUA_Hi = 12;         // High end of Dwelling Uniots Per Acre
        int DUA_Mn = 13;         // Mean or Median of Dwelling Uniots Per Acre
        int DUA_Lo = 14;         // Low end of Dwelling Uniots Per Acre
        int SGPSF_Hi = 15;       // High End of Seasonal Gallons Per SqFt Pervious Surface
        int SGPSF_Mn = 16;       // Mean or Median of Seasonal Gallons Per SqFt Pervious Surface
        int SGPSF_Lo = 17;       // Low end of Seasonal Gallons Per SqFt Pervious Surface    

        string[] FBFieldnames = new string[BFieldCount] { 
        "BTypeCode"     // Building Type Code
        ,"Btype"         // Building Type
        ,"PPHH"          // Persons Per Household
        ,"IGPCD"         // Default Indoor Gallons Per Capita per Day
        ,"DUA"           // Default Dweling Units Per Acre
        ,"SGPSF"         // Default Seasonal Gallons Per SqFt Pervious Surface
        ,"DummyInt"      // Slope Intercept for pervious surface function
        ,"DummyExp"      // Exponent for pervious surface function
        ,"DefaultPOP"    // Default population
        ,"IGPCD_Hi"      // High end of Indoor Gallons Per Capita per Day
        ,"IGPCD_Mn"      // Mean or Median of Indoor Gallons Per Capita per Day
        ,"IGPCD_Lo"      // Low end of Indoor Gallons Per Capita per Day
        ,"DUA_Hi"        // High end of Dwelling Uniots Per Acre
        ,"DUA_Mn"        // Mean or Median of Dwelling Uniots Per Acre
        ,"DUA_Lo"        // Low end of Dwelling Uniots Per Acre
        ,"SGPSF_Hi"      // High End of Seasonal Gallons Per SqFt Pervious Surface
        ,"SGPSF_Mn"      // Mean or Median of Seasonal Gallons Per SqFt Pervious Surface
        ,"SGPSF_Lo"      // Low end of Seasonal Gallons Per SqFt Pervious Surface    
        };

        string[] FBFieldLabels = new string[BFieldCount] { 
        "Building Type Code", 
        "Building Type"
        ,"Persons Per Household"
        ,"Default Indoor Gallons Per Capita per Day"
        ,"Default Dweling Units Per Acre"
        ,"Default Seasonal Gallons Per SqFt Pervious Surface"
        ,"Slope Intercept for pervious surface function"
        ,"Exponent for pervious surface function"
        ,"Default population"
        ,"High end of Indoor Gallons Per Capita per Day"
        ,"Mean or Median of Indoor Gallons Per Capita per Day"
        ,"Low end of Indoor Gallons Per Capita per Day"
        ,"High end of Dwelling Uniots Per Acre"
        ,"Mean or Median of Dwelling Uniots Per Acre"
        ,"Low end of Dwelling Uniots Per Acre"
        ,"High End of Seasonal Gallons Per SqFt Pervious Surface"
        ,"Mean or Median of Seasonal Gallons Per SqFt Pervious Surface"
        ,"Low end of Seasonal Gallons Per SqFt Pervious Surface"
        };

        // Name Lists
        List<string> FBuildingTypes = new List<string>();
        List<string> FBuildingTypeCodes = new List<string>();

        // Data
        
        string[] FTypeCodes;
        string[] FTypeLabels;
        double[] FPopulation;
        double[] FPersonsPerHousehold;
        double[] FIndoorGPCD;
        double[] FDwellingUnitsPerAcre;
        double[] FSeasonalGPSF;
        double[] FPerviousIntercept;
        double[] FPerviousExponent;

        double[][] FIndoorGPCD_Range;
        double[][] FDUA_Range;
        double[][] FSeasonalGPSF_Range;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <exception cref="Exception">    Thrown when error reading building data. </exception>
        ///
        /// <param name="DataFilename"> Filename of the data file. </param>
        ///-------------------------------------------------------------------------------------------------

        public BuildingDemandData(string DataFilename)
        {
            bool isErr = false;
            string errMsg = "";
            // split out the path and fieldname
            string dbPath =  Path.GetDirectoryName(DataFilename);
            string dbTablename = Path.GetFileName(DataFilename);
            if (dbPath != "")
            {
                // Create the DbConnection
                UniDbConnection DBCon = new UniDbConnection(SQLServer.stText, "", dbPath, "", "", "");
                try
                {
                    // Open and load table
                    DBCon.Open();
                    DBCon.UseFieldHeaders = true;
                    FBuildingData = Tools.LoadTable(DBCon, dbTablename, ref isErr, ref errMsg);
                    // if err throw exception
                    if (isErr)
                    {
                        throw new Exception("Error reading data: " + errMsg);
                    }
                    // check to seen if all the required fields are here
                    isErr = false;
                    errMsg = "";
                    foreach (string Fldstr in FBFieldnames)
                    {
                        if (!FBuildingData.Columns.Contains(Fldstr))
                        {
                            isErr = true;
                            errMsg += Fldstr + ",";
                        }
                    }
                    // if field missing throw exception
                    if (isErr)
                    {
                        throw new Exception("Error Loading Data : Required fields " + errMsg + " are missing!"); 
                    }
                    // Build the Lists
                    BuildTypeLists();
                    // Assign all values from datatable
                    assignValues();

                }
                catch (Exception ex)
                {
                    throw new Exception("Error Creating BuildingDemandData: " + ex.Message);
                }
            }
        }

        private void BuildTypeLists()
        {
            FBuildingTypeCodes.Clear();
            FBuildingTypes.Clear();
            foreach (DataRow DR in FBuildingData.Rows)
            {
                string Code = DR[FBFieldnames[BTypeCode]].ToString();
                FBuildingTypeCodes.Add(Code);
                string Name = DR[FBFieldnames[BType]].ToString();
                FBuildingTypes.Add(Name);
            }
        }

        private double ConvertDouble(string ValueStr)
        {
            double result;
            bool isErr = false;
            string errMsg = "";

            double temp = Tools.ConvertToDouble(ValueStr, ref isErr, ref errMsg);
            if (!isErr)
            {
                result = temp;
            }
            else
            {
                result = BADVALUE;
            }
            return result;

        }

        /// <summary>   Assign values. </summary>
        protected void assignValues()
        {
            // Setup
            int BTypeNumber = FBuildingData.Rows.Count;
            FTypeCodes = new string[BTypeNumber];
            FTypeLabels = new string[BTypeNumber];
            FPopulation = new double[BTypeNumber];
            FPersonsPerHousehold = new double[BTypeNumber];
            FIndoorGPCD = new double[BTypeNumber];
            FDwellingUnitsPerAcre = new double[BTypeNumber];
            FSeasonalGPSF = new double[BTypeNumber];
            FPerviousIntercept = new double[BTypeNumber];
            FPerviousExponent = new double[BTypeNumber];

            FIndoorGPCD_Range = new double[BTypeNumber][];
            FDUA_Range = new double[BTypeNumber][];
            FSeasonalGPSF_Range = new double[BTypeNumber][];
            // Assign Sub Cells
            for (int i = 0; i < BTypeNumber; i++)
            {
                FIndoorGPCD_Range[i] = new double[3];
                FDUA_Range[i] = new double[3];
                FSeasonalGPSF_Range[i] = new double[3];

            }

            // TypeCodes and labels
            for (int i = 0; i < BTypeNumber; i++)
            {
                FTypeCodes[i] = FBuildingTypeCodes[i];
                FTypeLabels[i] = FBuildingTypes[i];
            }
            // go through database, assign values
            int RecNum = 0;
            foreach (DataRow DR in FBuildingData.Rows)
            {
                FPopulation[RecNum] = ConvertDouble(DR[FBFieldnames[DefaultPOP]].ToString() );
                FPersonsPerHousehold[RecNum] = ConvertDouble(DR[FBFieldnames[PPHH]].ToString() );
                FIndoorGPCD[RecNum] = ConvertDouble(DR[FBFieldnames[IGPCD]].ToString() );
                FDwellingUnitsPerAcre[RecNum] = ConvertDouble(DR[FBFieldnames[DUA]].ToString() );
                FSeasonalGPSF[RecNum] = ConvertDouble(DR[FBFieldnames[SGPSF]].ToString() );
                FPerviousIntercept[RecNum] = ConvertDouble(DR[FBFieldnames[DummyInt]].ToString() );
                FPerviousExponent[RecNum] = ConvertDouble(DR[FBFieldnames[DummyExp]].ToString() );

                FIndoorGPCD_Range[RecNum][0] = ConvertDouble(DR[FBFieldnames[IGPCD_Lo]].ToString() );
                FIndoorGPCD_Range[RecNum][1] = ConvertDouble(DR[FBFieldnames[IGPCD_Mn]].ToString() );
                FIndoorGPCD_Range[RecNum][2] = ConvertDouble(DR[FBFieldnames[IGPCD_Hi]].ToString() );
                FDUA_Range[RecNum][0] = ConvertDouble(DR[FBFieldnames[DUA_Lo]].ToString() );
                FDUA_Range[RecNum][1] = ConvertDouble(DR[FBFieldnames[DUA_Mn]].ToString() );
                FDUA_Range[RecNum][2] = ConvertDouble(DR[FBFieldnames[DUA_Hi]].ToString() );
                FSeasonalGPSF_Range[RecNum][0] = ConvertDouble(DR[FBFieldnames[SGPSF_Lo]].ToString() );
                FSeasonalGPSF_Range[RecNum][1] = ConvertDouble(DR[FBFieldnames[SGPSF_Mn]].ToString() );
                FSeasonalGPSF_Range[RecNum][2] = ConvertDouble(DR[FBFieldnames[SGPSF_Hi]].ToString() );

                RecNum++;
            }

        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the information describing the building. </summary>
        ///
        /// <value> Information describing the building. </value>
        ///-------------------------------------------------------------------------------------------------

        public DataTable BuildingData
        {
            get { return FBuildingData; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the type codes. </summary>
        ///
        /// <value> The type codes. </value>
        ///-------------------------------------------------------------------------------------------------

        public string[] TypeCodes
        { get { return FTypeCodes; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the type labels. </summary>
        ///
        /// <value> The type labels. </value>
        ///-------------------------------------------------------------------------------------------------

        public string[] TypeLabels
        { get { return FTypeLabels; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the population. </summary>
        ///
        /// <value> The population. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] Population
        { get { return FPopulation; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the persons per household. </summary>
        ///
        /// <value> The persons per household. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] PersonsPerHousehold
        { get { return FPersonsPerHousehold; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the indoor gpcd. </summary>
        ///
        /// <value> The indoor gpcd. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] IndoorGPCD
        { get { return FIndoorGPCD; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the dwelling units per acre. </summary>
        ///
        /// <value> The dwelling units per acre. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] DwellingUnitsPerAcre
        { get { return FDwellingUnitsPerAcre; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the seasonal gpsf. </summary>
        ///
        /// <value> The seasonal gpsf. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] SeasonalGPSF
        { get { return FSeasonalGPSF; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the pervious intercept. </summary>
        ///
        /// <value> The pervious intercept. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] PerviousIntercept
        { get { return FPerviousIntercept; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the pervious exponent. </summary>
        ///
        /// <value> The pervious exponent. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] PerviousExponent
        { get { return FPerviousExponent; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the indoor gpcd range. </summary>
        ///
        /// <value> The indoor gpcd range. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[][] IndoorGPCD_Range
        { get { return FIndoorGPCD_Range; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the dua range. </summary>
        ///
        /// <value> The dua range. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[][] DUA_Range
        { get { return FDUA_Range; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the seasonal gpsf range. </summary>
        ///
        /// <value> The seasonal gpsf range. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[][] SeasonalGPSF_Range
        { get { return FSeasonalGPSF_Range; } }



    }

    // ################################################################################################
    /// <summary>   Building type water demand model. </summary>
    public class BuildingTypeWaterDemandModel
    {
        // DataTable Class
        BuildingDemandData FBData = null; 

        // Data
        string[] FTypeCodes;
        string[] FTypeLabels;
        double[] FPopulation;
        double[] FPersonsPerHousehold;
        double[] FIndoorGPCD;
        double[] FDwellingUnitsPerAcre;
        double[] FSeasonalGPSF;
        double[] FPerviousIntercept;
        double[] FPerviousExponent;

        double[][] FIndoorGPCD_Range;
        double[][] FDUA_Range;
        double[][] FSeasonalGPSF_Range;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="DataFilename"> Filename of the data file. </param>
        ///-------------------------------------------------------------------------------------------------

        public BuildingTypeWaterDemandModel(string DataFilename)
        {
            FBData = new BuildingDemandData(DataFilename);
            AssignData();
        }

        private void AssignData()
        {
            FTypeCodes = FBData.TypeCodes  ;
            FTypeLabels = FBData.TypeLabels  ;
            FPopulation = FBData.Population  ;
            FPersonsPerHousehold = FBData.PersonsPerHousehold  ;
            FIndoorGPCD = FBData.IndoorGPCD  ;
            FDwellingUnitsPerAcre = FBData.DwellingUnitsPerAcre  ;
            FSeasonalGPSF = FBData.SeasonalGPSF  ;
            FPerviousIntercept = FBData.PerviousIntercept  ;
            FPerviousExponent = FBData.PerviousExponent  ;

            FIndoorGPCD_Range = FBData.IndoorGPCD_Range  ;
            FDUA_Range = FBData.DUA_Range  ;
            FSeasonalGPSF_Range = FBData.SeasonalGPSF_Range;

        }

        /// <summary>   Executes the model operation. </summary>
        public void RunModel()
        {
            
        }
    }

    // ################################################################################################
    /// <summary>   Demand model. </summary>
    public class DemandModel
    {
        //Constants
        const double BADVALUE = double.NaN;
        const int FLandUseNumber = 7;
        const double SqFtInAcre = 43560;
        const double GallonsPerAcreFoot = 325851;
        public static int luLargeSF = 0;
        public static int luTypicalSF = 1;
        public const int luSmallSF = 2;
        public const int luSmallMF = 3;
        public const int luWalkupMF = 4;
        public const int luMidMF = 5;
        public const int luHighMF = 6;

        // Inputs
        
        
        // Population
        // Cell B13
        double FTP_TotalPop = 0;           // B13       Total Population

        // POP by building type
        // Cells B14:B20
        double[] FPopulation = new double[FLandUseNumber] { 0, 0, 0, 0, 0, 0, 0 };

       
        // Assumptions
        
        // Pervious Surface Equation Coefficients
        // From "Equation" worksheet
        // y = 30,001 * x^-1.167
        // 
        double FDummyInt = 30001;  // Cell Equation!B1
        double FDummyExp = -1.167;  // Cell Equation!B2

        // Persons Per Household
        // Cells G14:G20
        double[] FPersonPerHH = new double[FLandUseNumber] { 2.5, 2.5, 2.4, 2.4, 2.3, 2.1, 2.0 };  // defaults

        //  Indoor GPCD
        //  Cells H14:H20
        double[] FIndoorGPCD = new double[FLandUseNumber] { 50, 50, 50, 50, 50, 50, 50 }; // defaults
        
        // Dwelling Units Per Acre
        // Cells I14:I20
        double[] FDUA = new double[FLandUseNumber] { 5,7,10,14,20,35,60 };  // Defaults
        
        //  Seasonal Gallons Per Square Foot of pervious surface
        //  Cells J14:J20
        double[] FSeasonalGallonsPerSqFt = new double[FLandUseNumber] { 11.9, 8.2, 10, 14, 15, 18, 30 }; // Defaults
        
        /// <summary>   Default constructor. </summary>
        public DemandModel()
        {

        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the population. </summary>
        ///
        /// <value> The population. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] Population
        {
            get { return FPopulation; }
            set { FPopulation = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the persons per household </summary>
        ///
        /// <value> The persons per hh. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] PersonsPerHH
        {
            get { return FPersonPerHH; }
            set { FPersonPerHH = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the indoor Gallons Per Capita Per Day. </summary>
        ///
        /// <value> The indoor gpcd. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] IndoorGPCD
        {
            get { return FIndoorGPCD; }
            set { FIndoorGPCD = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the dwelling units per acre. </summary>
        ///
        /// <value> The dwelling units per acre. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] DwellingUnitsPerAcre
        {
            get { return FDUA; }
            set { FDUA = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the seasonal gallons per sq foot. </summary>
        ///
        /// <value> The seasonal gallons per sq foot. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] SeasonalGallonsPerSqFoot
        {
            get { return FSeasonalGallonsPerSqFt; }
            set { FSeasonalGallonsPerSqFt = value; }
        }

        //===========================================================================================
        // Derived factors.
        //===========================================================================================
        #region Derived Factors


        // ===========================================================================================
        // Estimated Acres Factors.
        //  
        // These are Derived from Cell B31   =((B14/$G14)/$I14)+((B15/$G15)/$I15)+((B16/$G16)/$I16)+((B17/$G17)/$I17)+((B18/$G18)/$I18)+((B19/$G19)/$I19)+((B20/$G20)/$I20)
        //=============================================================================================       

        public double[] EstimatedAcres()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                // check if factors not 0
                if ((FPersonPerHH[i] > 0) && (FDUA[i] > 0))
                {
                    // calculate Acres
                    result[i] = FPopulation[i] / FPersonPerHH[i] / FDUA[i];
                }
                else
                // if either = 0  set to BADVALUE
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total acres. </summary>
        ///
        /// <returns>   The total number of acres. </returns>
        ///-------------------------------------------------------------------------------------------------

        public double TotalAcres()
        {
            return Sum(EstimatedAcres());
        }
        //================================================================
        // UTILITIES
        // ===============================================================

        private double Sum(double[] values)
        {
            double result = 0;
            for(int i=0;i<values.Length;i++)
            {
                if (values[i]!=BADVALUE)
                {
                    result += values[i];
                }
                else
                {
                    result = BADVALUE;
                    break;
                }
            }
            return result;
        }
 
 
        //==================================================================
        // Estimated Pervious Area in SqFt    
        //    
        //  These are derived from cell B32
        //  =IFERROR(Equation!$B$1*($I14^Equation!$B$2)*(B14/$G14)/43560,0)+IFERROR(Equation!$B$1*($I15^Equation!$B$2)*(B15/$G15)/43560,0)+IFERROR(Equation!$B$1*($I16^Equation!$B$2)*(B16/$G16)/43560,0)+IFERROR(Equation!$B$1*($I17^Equation!$B$2)*(B17/$G17)/43560,0)+IFERROR(Equation!$B$1*($I18^Equation!$B$2)*(B18/$G18)/43560,0)+IFERROR(Equation!$B$1*($I19^Equation!$B$2)*(B19/$G19)/43560,0)+IFERROR(Equation!$B$1*($I20^Equation!$B$2)*(B20/$G20)/43560,0)
        //==================================================================

        public double[] EstimatedPerviousSqFt()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                // check if factors not 0
                if ((FPersonPerHH[i] > 0) && (FDUA[i] > 0))
                {
                    // calculate Perviopus area
                    result[i] = (FDummyInt * Math.Pow(FDUA[i], FDummyExp) * (FPopulation[i] / FPersonPerHH[i]));
                }
                else
                // if either = 0  set to BADVALUE
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total estimated pervious sq ft. </summary>
        ///
        /// <returns>   The total number of estimated pervious sq ft. </returns>
        ///-------------------------------------------------------------------------------------------------

        public double TotalEstimatedPerviousSqFt()
        {
            return Sum(EstimatedPerviousSqFt());
        }


        //==================================================================
        // Estimated Pervious Area in Acres   
        //    
        //  These are derived from cell B32
        //  =IFERROR(Equation!$B$1*($I14^Equation!$B$2)*(B14/$G14)/43560,0)+IFERROR(Equation!$B$1*($I15^Equation!$B$2)*(B15/$G15)/43560,0)+IFERROR(Equation!$B$1*($I16^Equation!$B$2)*(B16/$G16)/43560,0)+IFERROR(Equation!$B$1*($I17^Equation!$B$2)*(B17/$G17)/43560,0)+IFERROR(Equation!$B$1*($I18^Equation!$B$2)*(B18/$G18)/43560,0)+IFERROR(Equation!$B$1*($I19^Equation!$B$2)*(B19/$G19)/43560,0)+IFERROR(Equation!$B$1*($I20^Equation!$B$2)*(B20/$G20)/43560,0)
        //==================================================================

        public double[] EstimatedPerviousAcres()
        {
            // create array
            double[] result = EstimatedPerviousSqFt();
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                // calculate Perviopus area
                result[i] = result[i] / SqFtInAcre;
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total estimated pervious acres. </summary>
        ///
        /// <returns>   The total number of estimated pervious acres. </returns>
        ///-------------------------------------------------------------------------------------------------

        public double TotalEstimatedPerviousAcres()
        {
            return Sum(EstimatedPerviousAcres());
        }

        //==================================================================
        // Estmated Indoor Demand
        // Derived from Cell B33
        // 
        // =((B14*$H14*365)+(B15*$H15*365)+(B16*$H16*365)+(B17*$H17*365)+(B18*$H18*365)+(B19*$H19*365)+(B20*$H20*365))/325851
        // ======================================================================
         
        public double[] AnnualIndoorDemand()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                // calculate Indoor Demand
                result[i] = FPopulation[i] * FIndoorGPCD[i] * 365 / GallonsPerAcreFoot;
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total annual indoor demand. </summary>
        ///
        /// <returns>   The total number of annual indoor demand. </returns>
        ///-------------------------------------------------------------------------------------------------

        public double TotalAnnualIndoorDemand()
        {
            return Sum(AnnualIndoorDemand());
        }
        
        //====================================================================
        // Annaul Seasonal Demand
        // derived from CellB34
        // =IFERROR(((Equation!$B$1*($I14^Equation!$B$2)*(B14/$G14))*$J14)/325851,0)+IFERROR(((Equation!$B$1*($I15^Equation!$B$2)*(B15/$G15))*$J15)/325851,0)+IFERROR(((Equation!$B$1*($I16^Equation!$B$2)*(B16/$G16))*$J16)/325851,0)+IFERROR(((Equation!$B$1*($I17^Equation!$B$2)*(B17/$G17))*$J17)/325851,0)+IFERROR(((Equation!$B$1*($I18^Equation!$B$2)*(B18/$G18))*$J18)/325851,0)+IFERROR(((Equation!$B$1*($I19^Equation!$B$2)*(B19/$G19))*$J19)/325851,0)+IFERROR(((Equation!$B$1*($I20^Equation!$B$2)*(B20/$G20))*$J20)/325851,0)
        //====================================================================


        public double[] AnnualSeasonalDemand()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            // Get pervious area
            double[] Pervious = EstimatedPerviousSqFt();

            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                if (Pervious[i]!=BADVALUE)
                {

                    // calculate Indoor Demand
                    result[i] = Pervious[i] * FSeasonalGallonsPerSqFt[i] / GallonsPerAcreFoot;    
                }
                else
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total annual seasonal demand. </summary>
        ///
        /// <returns>   The total number of annual seasonal demand. </returns>
        ///-------------------------------------------------------------------------------------------------

        public double TotalAnnualSeasonalDemand()
        {
            return Sum(AnnualSeasonalDemand());
        }
        

        //====================================================================
        // Total Annaul Demand
        // derived from CellB35
        // =B33+B34
        //====================================================================

        public double[] AnnualDemand()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            // Get pervious area
            double[] Seasonal = AnnualSeasonalDemand();
            double[] Indoor = AnnualIndoorDemand();


            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                // check if factors not 0
                if ((Seasonal[i]!=BADVALUE) && (Indoor[i] !=BADVALUE))
                {
                    // calculate Indoor Demand
                    result[i] = Seasonal[i] + Indoor[i];   
                }
                else
                // if either = 0  set to BADVALUE
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }

        public double TotalAnnualDemand()
        {
            return Sum(AnnualDemand());
        }

        //====================================================================
        // Overall GPCD
        // derived from CellB36
        // =(B35*325851)/B13/365
        //====================================================================

        public double[] GPCD()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            double[] TotalDemand = AnnualDemand();
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                if ((TotalDemand[i]!=BADVALUE)&&(FPopulation[i]>0))
                {
                    // calculate Perviopus area
                    result[i] = (TotalDemand[i] * GallonsPerAcreFoot)/FPopulation[i]/365;
                }
                else
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average gpcd. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double AverageGPCD()
        {
            // create array
            double result = 0;
            double[] Demand = AnnualDemand();
            double AllDemand = 0;
            double AllPopulation = 0;
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                if ((Demand[i] != BADVALUE) && (FPopulation[i] != BADVALUE))
                {
                    AllDemand += Demand[i];
                    AllPopulation += FPopulation[i];
                }
                else
                {
                    AllDemand = BADVALUE;
                    AllPopulation = BADVALUE;
                    break;
                }
            }
            if ((AllDemand != BADVALUE) && (AllPopulation != BADVALUE) && (AllPopulation>0))
            {
                result = (AllDemand * GallonsPerAcreFoot)/ AllPopulation / 365;                
            }
            else
            {
                result = BADVALUE;
            }

            return result;
        }
        //====================================================================
        // Dwelling Units
        // derived from CellB37
        // =((B14/$G14)+(B15/$G15)+(B16/$G16)+(B17/$G17)+(B18/$G18)+(B19/$G19)+(B20/$G20))
        //====================================================================

        public double[] Units()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                if ((FPopulation[i] != BADVALUE) && (FPersonPerHH[i] > 0))
                {
                    // calculate Perviopus area
                    result[i] = FPopulation[i] / FPersonPerHH[i];
                }
                else
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total number of dwelling units. </summary>
        ///
        /// <returns>   The total number of units. </returns>
        ///-------------------------------------------------------------------------------------------------

        public double TotalUnits()
        {
            return Sum(Units());
        }
        
        //====================================================================
        // Gallons Per Unit per Year
        // derived from CellB38
        // =(B35*325851)/B37
        //====================================================================

        public double[] AnnualGallonsPerUnit()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            double[] TotalDemand = AnnualDemand();
            double[] TheUnits = Units();

            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                if ((TotalDemand[i] != BADVALUE) && (TheUnits[i] > 0))
                {
                    // calculate Perviopus area
                    result[i] = TotalDemand[i] * GallonsPerAcreFoot / TheUnits[i];
                }
                else
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average annual gallons per unit. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double AverageAnnualGallonsPerUnit()
        {
            double result = 0;
            double Demand = TotalAnnualDemand();
            double Units = TotalUnits();

            if ((Demand != BADVALUE) && (Units != BADVALUE))
            {
                result = (Demand * GallonsPerAcreFoot) / Units;
            }
            else
            {
                result = BADVALUE;
            }
            return result;
        }

        //====================================================================
        // AcreFeet per Acre per Year
        // derived from CellB39
        // =B35/B31
        //====================================================================

        public double[] AnnualAcreFeetPerAcre()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            double[] TotalDemand = AnnualDemand();
            double[] Acres = EstimatedAcres();
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                if ((TotalDemand[i] != BADVALUE) && (Acres[i] != BADVALUE))
                {
                    // calculate Annual Acre Feet Per Acre
                    result[i] = TotalDemand[i] / Acres[i];
                }
                else
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average annual acre feet per acre. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double AverageAnnualAcreFeetPerAcre()
        {
            double result = 0;
            double Demand = TotalAnnualDemand();
            double Acres = TotalAcres() ;

            if ((Demand != BADVALUE) && (Acres != BADVALUE))
            {
                result = Demand / Acres;
            }
            else
            {
                result = BADVALUE;
            }
            return result;
        }


        #endregion Derived Factors

    }
}
