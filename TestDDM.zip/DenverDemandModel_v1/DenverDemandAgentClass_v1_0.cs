﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgentClasses;

//=======================================================
//	Denver Demand Agent Classes
//	ver 1.0
//	3/7/17
//	Initial Developer Ray Quay
//	Notes
//
// ======================================================
// 
namespace DenverDemandAgentClass
{
	//==============================================================
	// Denver Demand Agent
	// Basically set up for different building types
	//
    //=============================================================================================
  
    class DenverDemandAgent : Agent
    {
        const int RangeSize = 3;
        // Base Data

        int FCurrentYear = 2015;
        double FPopulation = 0;
        double FPersonsPerHousehold = 0;
        double FIndoorGPCD = 0;
        double FDwellingUnitsPerAcre = 0;
        double FSeasonalGPSF = 0;
        double FPerviousIntercept = 30001;  // default
        double FPerviousExponent = -1.67;   // default
        double FAnnualDemand = 0.0;
        double FIndoorDemand = 0.0;
        double FOutdoorDemand = 0.0;

        double[] FIndoorGPCD_Range = new double[RangeSize];
        double[] FDUA_Range = new double[RangeSize];
        double[] FSeasonalGPSF_Range = new double[RangeSize];

        // Working Data

        double FUnits = 0;
        double FAllAcres = 0;
        double FPerviousSqFt = 0;

        public DenverDemandAgent(string aTypeCode, string aTypeLabel, double aPopulation, double aPersonsPerHH, double aIndoorGPCD, double aDUA, double aSeasonalGallonsPerSQFT)
            : base(aTypeCode, aTypeLabel)
        {
            FPopulation = aPopulation;
            FPersonsPerHousehold = aPersonsPerHH;
            FIndoorGPCD = aIndoorGPCD;
            FDwellingUnitsPerAcre = aDUA;
            FSeasonalGPSF = aSeasonalGallonsPerSQFT;
            FPerviousIntercept = 0;
            FPerviousExponent = 0;
        }

        public DenverDemandAgent(string aTypeCode, string aTypeLabel, double aPopulation, double aPersonsPerHH, double aIndoorGPCD, double aDUA, double aSeasonalGallonsPerSQFT,
                                 double aPerviousIntercept, double aPerviousExponent, double[] anIndoorRange, double[] aDUARange, double[] aSeasonalRange)
            : base(aTypeCode, aTypeLabel)
        {
            FPopulation = aPopulation;
            FPersonsPerHousehold = aPersonsPerHH;
            FIndoorGPCD = aIndoorGPCD;
            FDwellingUnitsPerAcre = aDUA;
            FSeasonalGPSF = aSeasonalGallonsPerSQFT;
            FPerviousIntercept = aPerviousIntercept;
            FPerviousExponent = aPerviousExponent;
            FIndoorGPCD_Range = anIndoorRange;
            FDUA_Range = aDUARange;
            FSeasonalGPSF_Range = aSeasonalRange;
        }
        //==================================================================
        // Operation Methods
        // =================================================================
        public override bool Run()
        {
            EstimateDemand(FCurrentYear);

            return base.Run();
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Estimated demand. </summary>
        ///
        /// <param name="year"> The year. </param>
        ///-------------------------------------------------------------------------------------------------

        public void EstimateDemand(int year)
        {
            FAnnualDemand = 0;
            if (FPersonsPerHousehold > 0)
            {
                FUnits = FPopulation / FPersonsPerHousehold;
            }
            else
            {
                throw new AgentException("Persons Per Household must be greater than 0. ID:" + FName);
            }
            if (FDwellingUnitsPerAcre > 0)
            {
                FAllAcres = FUnits / FDwellingUnitsPerAcre;
            }
            else
            {
                throw new AgentException("Dweling Units Per Acre must be greater than 0. ID:" + FName);
            }

            FPerviousSqFt = FPerviousIntercept * Math.Pow(FDwellingUnitsPerAcre, FPerviousExponent) * FUnits;
            FOutdoorDemand = FPerviousSqFt * FSeasonalGPSF;
            FIndoorDemand = Population * FIndoorGPCD;

            FAnnualDemand = FIndoorDemand + FOutdoorDemand;
        }
        //====================================================================
        // Properties
        // ===================================================================

        public int CurrentYear
        {
            get { return FCurrentYear; }
            set { FCurrentYear = value; }
        }

        public double Population
        {
            get { return FPopulation; }
            set { FPopulation = value; }
        }
        public double PersonsPerHousehold
        {
            get { return FPersonsPerHousehold; }
            set { FPersonsPerHousehold = value; }
        }
        public double IndoorGPCD
        {
            get { return FIndoorGPCD; }
            set { FIndoorGPCD = value; }
        }
        public double DwellingUnitsPerAcre
        {
            get { return FDwellingUnitsPerAcre; }
            set { FDwellingUnitsPerAcre = value; }
        }
        public double SeasonalGPSF
        {
            get { return FSeasonalGPSF; }
            set { FSeasonalGPSF = value; }
        }
        public double PerviousIntercept
        {
            get { return FPerviousIntercept; }
            set { FPerviousIntercept = value; }
        }
        public double PerviousExponent
        {
            get { return FPerviousExponent; }
            set { FPerviousExponent = value; }
        }
        public double[] IndoorGPCD_Range
        {
            get { return FIndoorGPCD_Range; }
            set { FIndoorGPCD_Range = value; }
        }
        public double[] DUA_Range
        {
            get { return FDUA_Range; }
            set { FDUA_Range = value; }
        }
        public double[] SeasonalGPSF_Range
        {
            get { return FSeasonalGPSF_Range; }
            set { FSeasonalGPSF_Range = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the acres. </summary>
        ///
        /// <value> The acres. </value>
        ///-------------------------------------------------------------------------------------------------

        public double Acres
        {
            get { return FAllAcres; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the pervious acres. </summary>
        ///
        /// <value> The pervious acres. </value>
        ///-------------------------------------------------------------------------------------------------

        public double PerviousAcres
        {
            get { return FPerviousSqFt / 43560; }
        }
    }

	//============================================================
	// Denver Demand Agent Model
	// ===========================================================

}
