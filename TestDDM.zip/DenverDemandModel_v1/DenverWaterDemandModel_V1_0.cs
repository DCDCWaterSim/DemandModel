﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BuildingTypes;
using WaterDemandAgentClass;
using System.IO;

namespace DenverDemandModel_v1
{
    public class DenverHouseholdData
    {
        BuildingType BT;
        string FName = "";
        string FTypeCode = "";
        string FLabel = "";
        string FBuildCode;
        double FPersonsPerHoushold;
        double FHouseHoldNumber;
        double FIndoorGPCD;
        double FGallonsPerSqFt;
        double FDwellingUnitsPerAcre;
        double[] FGallonsPerSqFt_Range;
        double[] FEmptyRange = new double[3] { 0, 0, 0 };


        public DenverHouseholdData(string aName, string aTypeCode, string aLabel, string aBuildCode, double aPersonsPerHoushold, double Population, double anIndoorGPCD, double aGallonsPerSqFt, double aDwellingUnitsPerAcre)
        {
            BuildingType BT = new BuildingType(FBuildCode,FBuildCode+"_Households",FDwellingUnitsPerAcre,FEmptyRange,FGallonsPerSqFt,FEmptyRange, aPersonsPerHoushold);
            FName = aName;
            FTypeCode = aTypeCode;
            FLabel = aLabel;
            FBuildCode = aBuildCode;
            FPersonsPerHoushold = aPersonsPerHoushold;
            FHouseHoldNumber = Population / FPersonsPerHoushold;
            FIndoorGPCD=anIndoorGPCD;
            FGallonsPerSqFt=aGallonsPerSqFt;
            FDwellingUnitsPerAcre=aDwellingUnitsPerAcre;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the gallons per sq ft range. </summary>
        ///
        /// <value> The gallons per sq ft range. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] GallonsPerSqFt_Range
        {
            get { return FGallonsPerSqFt_Range; }
            set { FGallonsPerSqFt_Range = value; }
        }

        public HouseHoldWaterDemand NewHousehold()
        {

            BuildingType BT = new BuildingType(FBuildCode,FBuildCode+"_Households",FDwellingUnitsPerAcre,FEmptyRange,FGallonsPerSqFt,FEmptyRange, FPersonsPerHoushold);
            HouseHoldWaterDemand HHWD = new HouseHoldWaterDemand(FTypeCode,FLabel,FName,BT, FPersonsPerHoushold, FHouseHoldNumber, FIndoorGPCD);
            return HHWD;
        }

        public HouseHoldWaterDemand[] NewHouseholdsGallonsPerSqftRange()
        {
            HouseHoldWaterDemand[] HHs = new HouseHoldWaterDemand[3];
            for (int i = 0; i < 3; i++)
            {
                BuildingType BT = new BuildingType(FBuildCode, FBuildCode + "_Households", FDwellingUnitsPerAcre, FEmptyRange, FGallonsPerSqFt_Range[i], FEmptyRange, FPersonsPerHoushold);
                HouseHoldWaterDemand HHWD = new HouseHoldWaterDemand(FTypeCode, FLabel, FName, BT, FPersonsPerHoushold, FHouseHoldNumber, FIndoorGPCD);
                HHs[i] = HHWD;
            }
            return HHs;
        }
    }

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   A water agent data by building type. </summary>
    ///
    /// <remarks>   3/21/2017. </remarks>
    ///-------------------------------------------------------------------------------------------------

    public class WaterAgentDataByBuildingType 
    {
        string FBTypeCode;
        double FUnits;
        double FPeople;
        double FAverageHHSize;
        double FDemand;
        double FIndoor;
        double FOutdoor;
        double FProcess;
        double FDevAcres;
        double FPervAcres;
        double FGallonsSqFt;
        double FAvgDemandPerAcre;
        double FAvgDemandPerUnit;
        double FAvgGPCD;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <remarks>   3/21/2017. </remarks>
        ///
        /// <param name="BTypeCode">    The type code. </param>
        /// <param name="TheCommunity"> the community. </param>
        ///-------------------------------------------------------------------------------------------------

        public WaterAgentDataByBuildingType(string BTypeCode, CommunityWaterDemand TheCommunity)
        {
            List<WaterDemandAgent> ListByCode = TheCommunity.FindByTypeCode(BTypeCode);
            FBTypeCode = BTypeCode;
            FUnits = 0;
            FPeople = 0;
            FAverageHHSize = 0;
            FDemand = 0;
            FIndoor = 0;
            FOutdoor = 0;
            FProcess = 0;
            FDevAcres = 0;
            FPervAcres = 0;
            FGallonsSqFt = 0;


            double Count = 0;
            foreach (WaterDemandAgent WDA in ListByCode)
            {
                if (WDA is HouseHoldWaterDemand)
                {
                    Count++;
                    FUnits += (WDA as HouseHoldWaterDemand).NumberOfHouseholds;
                    FPeople += (WDA as HouseHoldWaterDemand).HouseHoldSize * (WDA as HouseHoldWaterDemand).NumberOfHouseholds;
                    FDemand += WDA.TotalDemand;
                    FIndoor += WDA.IndoorDemand;
                    FOutdoor += WDA.OutdoorDemand;
                    FProcess += WDA.ProcessDemand;
                    FDevAcres += (WDA as HouseHoldWaterDemand).DevelopedAcres;
                    FPervAcres += (WDA as HouseHoldWaterDemand).PerviousSqFt / 43560;
                    FGallonsSqFt += (WDA as HouseHoldWaterDemand).OutdoorGallonsPerSqFt;
                }
            }

            if (Count > 0)
            {
                FGallonsSqFt = FGallonsSqFt / Count;
            }
            if (FUnits > 0)
            {
                FAverageHHSize = FPeople / FUnits;
                FAvgDemandPerUnit = FDemand / FUnits;
            }
            if (FDevAcres > 0)
            {
                FAvgDemandPerAcre = FDemand / FDevAcres;
            }
            if (FPeople > 0)
            {
                FAvgGPCD = FDemand / FPeople / 365;
            }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the build type code. </summary>
        /// <value> The build type code. </value>
        ///-------------------------------------------------------------------------------------------------
        public string BuildTypeCode
        { get { return    FBTypeCode;}}        

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the units. </summary>
        /// <value> The units. </value>
        ///-------------------------------------------------------------------------------------------------
        public double Units
        { get { return     FUnits; }}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the people. </summary>
        /// <value> The people. </value>
        ///-------------------------------------------------------------------------------------------------
        public double People
        { get { return     FPeople;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the size of the average hh. </summary>
        /// <value> The size of the average hh. </value>
        ///-------------------------------------------------------------------------------------------------
        public double AvgHHSize
        { get { return     FAverageHHSize;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total number of demand. </summary>
        /// <value> The total number of demand. </value>
        ///-------------------------------------------------------------------------------------------------
        public double TotalDemand
        { get { return     FDemand;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the indoor demand. </summary>
        /// <value> The indoor demand. </value>
        ///-------------------------------------------------------------------------------------------------
        public double IndoorDemand
        { get { return     FIndoor;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the outdoor demand. </summary>
        /// <value> The outdoor demand. </value>
        ///-------------------------------------------------------------------------------------------------
        public double OutdoorDemand
        { get { return FOutdoor;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the process demand. </summary>
        /// <value> The process demand. </value>
        ///-------------------------------------------------------------------------------------------------
        public double ProcessDemand
        { get { return     FProcess;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the development acres. </summary>
        ///
        ///-------------------------------------------------------------------------------------------------
        public double DevAcres
        { get { return     FDevAcres;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the pervious acres. </summary>
        /// <value> The pervious acres. </value>
        ///-------------------------------------------------------------------------------------------------
        public double PerviousAcres
        { get { return     FPervAcres;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the gallons sq ft pervious. </summary>
        /// <value> The gallons sq ft pervious. </value>
        ///-------------------------------------------------------------------------------------------------
        public double GallonsSqFtPervious
        { get { return     FGallonsSqFt;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average demand per acre. </summary>
        /// <value> The average demand per acre. </value>
        ///-------------------------------------------------------------------------------------------------
        public double AvgDemandPerAcre
        { get { return     FAvgDemandPerAcre;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average demand per unit. </summary>
        /// <value> The average demand per unit. </value>
        ///-------------------------------------------------------------------------------------------------
        public double AvgDemandPerUnit
        { get { return     FAvgDemandPerUnit;}}

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average gocd. </summary>
        /// <value> The average gocd. </value>
        ///-------------------------------------------------------------------------------------------------
        public double AverageGOCD
        { get { return     FAvgGPCD;}}


        private string BuildField (string Code, string fieldstr, string Marker)
        {
            return Marker + Code + "_" + fieldstr;
        }

        public string ToFieldHeader(string Format)
        {
            string result = "";
            const string Tag = "_";
            // Setup Formatting
            Format = Format.ToUpper();
            string Mark = "";
            switch (Format)
            {
                case "CSV":
                    Mark = ",";
                    break;
                case "TAB":
                    Mark = "/t";
                    break;
            }
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }
            result = BuildField(BuildTypeCode, "UNITS", Mark);
            result += BuildField(BuildTypeCode, "PERS", Mark);
            result += BuildField(BuildTypeCode, "AVGHH", Mark);
            result += BuildField(BuildTypeCode, "DEM", Mark);
            result += BuildField(BuildTypeCode, "INDEM", Mark);
            result += BuildField(BuildTypeCode, "OUTDEM", Mark);
            result += BuildField(BuildTypeCode, "PRCDEM", Mark);
            result += BuildField(BuildTypeCode, "DACRES", Mark);
            result += BuildField(BuildTypeCode, "PACRES", Mark);
            result += BuildField(BuildTypeCode, "GSF", Mark);
            result += BuildField(BuildTypeCode, "DEMACR", Mark);
            result += BuildField(BuildTypeCode, "DEMUNT", Mark);
            result += BuildField(BuildTypeCode, "GPCD", Mark);
            return result;

        }

        public string ToXMLDefineString(string Indent)
        {
            string result = "";
            string Mark = "";
            result +=  CommunityWaterDemand.XMLField(Indent,BuildField(BuildTypeCode, "UNITS", Mark),"The total number of units for all agents with the "+BuildTypeCode+" Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "PERS", Mark), "The total number of persons  for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "AVGHH", Mark), "The average household size for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "DEM", Mark), "The total demand (indoor, outdoor, process) for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "INDEM", Mark), "The total indoor demand for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "OUTDEM", Mark), "The total outdoor demand for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "PRCDEM", Mark), "The total process demand for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "DACRES", Mark), "The total number of acres developed for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "PACRES", Mark), "The total number of pervious arres for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "GSF", Mark), "The gallons per sqft of pervious area for the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "DEMACR", Mark), "The average demand per acre for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "DEMUNT", Mark), "The average demand per unit/household for all agents with the " + BuildTypeCode + " Buiulding Type");
            result += CommunityWaterDemand.XMLField(Indent, BuildField(BuildTypeCode, "UNITS", Mark), "The average gallons per capita per daya for all agents with the " + BuildTypeCode + " Buiulding Type");
            return result;

        }
        private string BuildValueStr(double Value, string Marker)
        {
            return Marker + Value.ToString("F2");
        }

        private double ConvertToAF(double value)
        {
            return value / 328581;
        }

        public string ToString(string Format)
        {
            string result = "";
            // Setup Formatting
            Format = Format.ToUpper();
            string Mark = "";
            switch (Format)
            {
                case "CSV":
                    Mark = ",";
                    break;
                case "TAB":
                    Mark = "/t";
                    break;
            }
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }
            result = Mark + FUnits.ToString("F2");
            result += Mark + FPeople.ToString("F2");
            result += Mark + FAverageHHSize.ToString("F2");
            result += Mark + ConvertToAF(FDemand).ToString("F2");
            result += Mark + ConvertToAF(FIndoor).ToString("F2");
            result += Mark + ConvertToAF(FOutdoor).ToString("F2");
            result += Mark + ConvertToAF(FProcess).ToString("F2");
            result += Mark + FDevAcres.ToString("F2");
            result += Mark + FPervAcres.ToString("F2");
            result += Mark + FGallonsSqFt.ToString("F2");
            result += Mark + ConvertToAF(FAvgDemandPerAcre).ToString("F2");
            result += Mark + ConvertToAF(FAvgDemandPerUnit).ToString("F2");
            result += Mark + FAvgGPCD.ToString("F2");
            return result;
        }
    }

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   Denver community. </summary>
    ///
    /// <seealso cref="WaterDemandAgentClass.CommunityWaterDemand"/>
    ///-------------------------------------------------------------------------------------------------

    public class DenverCommunity : CommunityWaterDemand
    {
        double FTotalUnits = 0.0;
        double FTotalDevAcres = 0.0;
        // Calculated
        double FAvgHouseholdSize = 0.0;
        double FAvgDUA = 0.0;
        double FTotalPeople = 0.0;

        List<WaterAgentDataByBuildingType> BTDataList = new List<WaterAgentDataByBuildingType>();
        
        BuildingTypeList BuildTypes;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="Name">         The name. </param>
        /// <param name="aBuildList">   List of builds. </param>
        ///-------------------------------------------------------------------------------------------------

        public DenverCommunity(string Name, BuildingTypeList aBuildList) : base(Name)
        {
            BuildTypes = aBuildList;
        }

        /// <summary>   Sum build type data. </summary>
        protected virtual void SumBuildTypeData()
        {
            BTDataList.Clear();

            foreach (BuildingType BT in BuildTypes)
            {
                WaterAgentDataByBuildingType WADBT = new WaterAgentDataByBuildingType(BT.Code, this);
                if (WADBT != null)
                {
                    BTDataList.Add(WADBT);
                }
            }
        }

        /// <summary>   Sum stats. </summary>
        protected virtual void SumStats()
        {
            FTotalUnits = 0.0;
            FTotalDevAcres = 0.0;
            FTotalPeople = 0.0;

            foreach (WaterDemandAgent WDA in this)
            {
                if (WDA is HouseHoldWaterDemand)
                {
                    double Units = (WDA as HouseHoldWaterDemand).NumberOfHouseholds;
                    double HHSize = (WDA as HouseHoldWaterDemand).HouseHoldSize;

                    FTotalUnits += Units;
                    FTotalDevAcres += (WDA as HouseHoldWaterDemand).DevelopedAcres;
                    FTotalPeople +=  Units * HHSize;
                }
            }
            if (FTotalUnits > 0)
            {
                FAvgHouseholdSize = FTotalPeople / FTotalUnits;
            }
            if (FTotalDevAcres > 0)
            {
               FAvgDUA = FTotalUnits / FTotalDevAcres;
            }
            
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Runs all the Agents. </summary>
        ///
        /// <returns>   . </returns>
        ///
        /// <seealso cref="WaterDemandAgentClass.CommunityWaterDemand.Run()"/>
        ///-------------------------------------------------------------------------------------------------

        public override int Run()
        {
            // Run the base (Which sums up demands)
            int result = base.Run();
            // now sum up stats by Buiulding type
            SumBuildTypeData();
            // Now Calc other Houshold parameters
            SumStats();
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Other stats to string. </summary>
        ///
        /// <param name="Format">   Describes the format to use. </param>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        protected string OtherStatsToString(string Format)
        {
            string result = "";
            // Setup Formatting
            string Mark = GetMark(Format);
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }
            else
            {
                string UnitStr = FTotalUnits.ToString("F2");
                string DevAcresStr = FTotalDevAcres.ToString("F2");
                string HHSizeStr = FAvgHouseholdSize.ToString("F2");
                string DUAStr = FAvgDUA.ToString("F2");
                string PeopleStr = FTotalPeople.ToString("F2");
                result = Mark + UnitStr + Mark + DevAcresStr + Mark + HHSizeStr + Mark + DUAStr + Mark + PeopleStr;

            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Other stats header string. </summary>
        ///
        /// <param name="Format">   Describes the format to use. </param>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        protected string OtherStatsHeaderString(string Format)
        {
            string result = "";
            // Setup Formatting
            string Mark = GetMark(Format);
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }
            else
            {
                result = Mark + "TotalUnits" + Mark + "TotalAcres" + Mark + "AvgHHSize" + Mark + "AvgDUA" + Mark + "TotalPeople";

            }
            return result;
        }


        public override string ToXMLDefineString(string Indent)
        {
            string result = base.ToXMLDefineString(Indent);
            result += XMLField(Indent, "TotalUnits", "The total of all units/households for all household demand agents within the Community scenario");
            result += XMLField(Indent, "TotalAcres", "The total of all developed acres for all household demand agents within the Community scenario");
            result += XMLField(Indent, "AvgHHSize", "The average household size for all household demand agents within the Community scenario (TotalPeople / TotalUnits)");
            result += XMLField(Indent, "AvgDUA", "The average dwelling units per acre all household demand agents within the Community scenario (TotalUnits / TotalAcres)");
            result += XMLField(Indent, "TotalPeople", "The total of all the people for all household demand agents within the Community scenario");
            foreach (WaterAgentDataByBuildingType WADBT in BTDataList)
            {
                result += WADBT.ToXMLDefineString(Indent);
            }
            return result;
        }

        public string XMLDocumentation(string Indent)
        {
            string result = Indent + "<COMMUNITY>"+Environment.NewLine;
            result += Indent + "   " + "<NAME>" + Name + "</NAME>" + Environment.NewLine;
            result += Indent + "   " + "<FIELDS>" + Environment.NewLine;
            result += ToXMLDefineString(Indent + "     ");
            result += Indent + "   " + "</FIELDS>" + Environment.NewLine;
            result += Indent + "</COMMUNITY>" + Environment.NewLine;
            return result;
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Convert this object into a string representation. </summary>
        ///
        /// <param name="Format">   Describes the format to use. </param>
        ///
        /// <returns>   A string that represents this object. </returns>
        ///
        /// <seealso cref="WaterDemandAgentClass.CommunityWaterDemand.ToString(string)"/>
        ///-------------------------------------------------------------------------------------------------

        public override string ToString(string Format)
        {
            string result = base.ToString(Format) + OtherStatsToString(Format);

            foreach (WaterAgentDataByBuildingType WADBT in BTDataList)
            {
                result += WADBT.ToString(Format);
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Converts a Format to a field header string. </summary>
        ///
        /// <param name="Format">   Describes the format to use. </param>
        ///
        /// <returns>   Format as a string. </returns>
        ///
        /// <seealso cref="WaterDemandAgentClass.CommunityWaterDemand.ToFieldHeaderString(string)"/>
        ///-------------------------------------------------------------------------------------------------

        public override string ToFieldHeaderString(string Format)
        {
            string result = base.ToFieldHeaderString(Format) + OtherStatsHeaderString(Format);
            foreach (WaterAgentDataByBuildingType WADBT in BTDataList)
            {
                result += WADBT.ToFieldHeader(Format);
            }
            return result;

        }


    }

    //==============================================================================================================
    // 
    /// <summary>   Denver water demand model. </summary>
    public class DenverWaterDemandModel
    {
        DenverCommunity FDenverCommunity;
        BuildingTypeList BuildList;

        BaseScenario BaseScenarioData;
        public DenverWaterDemandModel(string Filename)
        {
            BuildList = new BuildingTypeList(Filename);
            BaseScenarioData = new BaseScenario(BuildList);
            FDenverCommunity = new DenverCommunity("Denver", BuildList);

        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets a list of build types. </summary>
        ///
        /// <value> The types of the builds. </value>
        ///-------------------------------------------------------------------------------------------------

        public BuildingTypeList BuildTypeList
        {
            get { return BuildList; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the water demand agents. </summary>
        ///
        /// <value> The water demand agents. </value>
        ///-------------------------------------------------------------------------------------------------

        public CommunityWaterDemand WaterDemandAgents
        {
            get { return FDenverCommunity; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the run. </summary>
        /// <remarks>   Returns the number of Agents that Run was succesful</remarks>
        /// <returns>   An int. </returns>
        ///-------------------------------------------------------------------------------------------------

        public int Run()
        {
            return FDenverCommunity.Run();
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Executes the scenario operation. </summary>
        /// <param name="aScenario">    The scenario. </param>
        ///
        /// <returns>   An int. </returns>
        ///-------------------------------------------------------------------------------------------------

        public int RunScenario(DemandScenario aScenario)
        {
            FDenverCommunity.Clear();
            foreach (HouseHoldWaterDemand HWD in aScenario.HouseholdList)
            {
                FDenverCommunity.Add(HWD);
            }
            int result = FDenverCommunity.Run();
            return result;
        }

        public string ResultsByBuildingType(string Format, out string FieldHeader)
        {
            string results = "";
            string fieldheaderStr = "";
            foreach (BuildingType BT in BuildList)
            {
                WaterAgentDataByBuildingType WADBT = new WaterAgentDataByBuildingType(BT.Code, FDenverCommunity);
                results += WADBT.ToString(Format);
                fieldheaderStr += WADBT.ToFieldHeader(Format);
            }
            FieldHeader = fieldheaderStr;
            return results;
        }


        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Executes the scenario operation. </summary>
        /// <param name="aScenario">    The scenario. </param>
        /// <param name="Format">       Describes the format to use. </param>
        /// <param name="FieldHeader">  [out] The field header. </param>
        ///
        /// <returns>   A string. </returns>
        ///-------------------------------------------------------------------------------------------------

        public string RunScenario(DemandScenario aScenario, string Format, out string FieldHeader)
        {
            string Result = "";
            string FieldHeaderStr = "";
            int test = RunScenario(aScenario);
            if (test > 0)
            {
                Result = FDenverCommunity.ToString(Format);
                FieldHeaderStr = FDenverCommunity.ToFieldHeaderString(Format);

                //string Extended = ResultsByBuildingType(Format, out FieldHeader);
                //Result += Extended;
            }
            FieldHeader = FieldHeaderStr;
            return Result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Executes the scenario operation. </summary>
        ///
        /// <remarks>   3/22/2017. </remarks>
        ///
        /// <param name="aScenario">    The scenario. </param>
        /// <param name="Format">       Describes the format to use. </param>
        ///
        /// <returns>   A string. </returns>
        ///-------------------------------------------------------------------------------------------------

        public string RunScenario(DemandScenario aScenario, string Format)
        {
            string Result = "";
            int test = RunScenario(aScenario);
            if (test > 0)
            {
                Result = FDenverCommunity.ToString(Format);
            }
            return Result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Call back. </summary>
        /// <param name="text">     The text. </param>
        /// <param name="max">      The maximum. </param>
        /// <param name="value">    The value. </param>
        ///-------------------------------------------------------------------------------------------------

        public delegate void CallBack(string text, int max, int value);

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Executes the scenario operation on a list of scenarios. </summary>
        /// <param name="aScenarios">   The scenarios. </param>
        /// <param name="Format">       Describes the format to use. </param>
        /// <param name="Report">       The report. </param>
        /// <param name="ReportonCnt">  Number of reportons. </param>
        ///
        /// <returns>   A string. </returns>
        ///-------------------------------------------------------------------------------------------------

        public string RunScenario(DemandScenarioList aScenarios, string Format, out string FieldHeader, CallBack Report, int ReportonCnt)
        {
            string result = "";

            int rcnt = 0;
            int scnt = 0;
            int MaxCnt = aScenarios.Count;
            FieldHeader = "";
            int cnt = 0;
            foreach (DemandScenario DS in aScenarios)
            {
                string FieldTemp = "";
                string temp = ""; 
                // ok if first item, grab a fieldheader
                if (cnt == 0)
                {
                    temp = RunScenario(DS, Format, out FieldTemp);
                    FieldHeader = FieldTemp;
                    cnt++;
                }
                else
                // otherwise faster not tyo do that
                {
                    temp = RunScenario(DS, Format);
                }
                // add to resul string
                result += temp + Environment.NewLine;
                // if report, do it
                if (Report != null)
                {
                    rcnt++;
                    scnt++;
                    if (rcnt == ReportonCnt)
                    {
                        rcnt = 0;
                        Report("Processing Scenarios", MaxCnt, scnt);
                    }
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Executes the scenario operation. </summary>
        ///
        /// <remarks>   3/22/2017. </remarks>
        ///
        /// <param name="aScenarios">   The scenarios. </param>
        /// <param name="Format">       Describes the format to use. </param>
        /// <param name="Filename">     Filename of the file. </param>
        /// <param name="Report">       The report. </param>
        /// <param name="ReportonCnt">  Number of reportons. </param>
        /// <param name="ErrMessage">   [out] Message describing the error. </param>
        ///
        /// <returns>   true if it succeeds, false if it fails. </returns>
        ///-------------------------------------------------------------------------------------------------

        public bool RunScenario(DemandScenarioList aScenarios, string Format, string Filename, CallBack Report, int ReportonCnt, out string ErrMessage)
        {
            bool result = false;
            string errMsg = "";
            int rcnt = 0;
            int scnt = 0;
            int MaxCnt = aScenarios.Count;

            try
            {
                using (StreamWriter SW = new StreamWriter(Filename))
                {
                    string FieldHeader = "";
                    int cnt = 0;
                    // loop through scenbario list
                    foreach (DemandScenario DS in aScenarios)
                    {
                        string FieldTemp = "";
                        string temp = "";
                        // if first recvord, grab and write fieldheader
                        if (cnt == 0)
                        {
                            temp = RunScenario(DS, Format, out FieldTemp);
                            FieldHeader = FieldTemp;
                            SW.WriteLine(FieldHeader);
                            cnt++;
                        }
                        else
                        // else faster to not get header
                        {
                            temp = RunScenario(DS, Format);
                        }
                        // write results to file
                        SW.WriteLine(temp);
                        // if report, do it
                        if (Report != null)
                        {
                            rcnt++;
                            scnt++;
                            if (rcnt == ReportonCnt)
                            {
                                rcnt = 0;
                                Report("Processing Scenarios", MaxCnt, scnt);
                            }
                        }
                    }
                    // should be all done everything worked
                }
                
                string Directory = Path.GetDirectoryName(Filename);
                string JustName = Path.GetFileNameWithoutExtension(Filename);
                string XMLFilename = Directory + "\\"+JustName + ".xml";
                using (StreamWriter SW = new StreamWriter(XMLFilename))
                {
                    string XMLDOC = FDenverCommunity.XMLDocumentation("  ");
                    SW.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                    SW.WriteLine("<DENVERDEMANDMODEL>" + Environment.NewLine);
                    SW.WriteLine("  <FILENAME>" + Filename + "</FILENAME>" + Environment.NewLine);
                    SW.Write(XMLDOC);
                    SW.WriteLine("</DENVERDEMANDMODEL>" + Environment.NewLine);
                }
                result = true;
            }
            catch (Exception ex)
            {
                // ouch and error
                errMsg = ex.Message;
            }
            ErrMessage = errMsg;
            return result;
        }

        private void ZeroOut(double[] Values)
        {
            for (int i = 0; i < Values.Length; i++)
            {
                Values[i] = 0.0;
            }
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Generates a land scenarios. </summary>
        ///
        /// <remarks>   3/22/2017. </remarks>
        ///
        /// <param name="Allocate"> An array of values for how much to shift households from oen catgory to another catgories
        ///                         </param>
        /// <remarks>   an array of 0, 0,15, 0.3  Would not allocate any HH in first scenario, would allocate 15% of HHs in second and 30% in last</remarks>
        /// <returns>   The land scenarios. </returns>
        ///-------------------------------------------------------------------------------------------------

        public DemandScenarioList GenerateLandScenarios(double[] Allocate)
        {
            double count = 0;
            double testcnt = 0;
            const int TOTALALLOCATION = 7;  // Number of Building Types
            int BUILDN = BuildList.Count;
            DemandScenarioList DSL = new DemandScenarioList();

            int options = Allocate.Length;
            // build allocation array, used to create scenarios
            double[][] Allocations = new double[BUILDN][];
            for(int i=0; i<BUILDN; i++)
            {
                Allocations[i] = new double[TOTALALLOCATION+1];  // Last One is the Remaining allocation (ie left behind)
                ZeroOut(Allocations[i]);

                //for (int j = 0; j < TOTALALLOCATION; j++)
                //{
                //    Allocations[i][j] = 0.0;
                //}
            }

            // The Big Loops
            // Loop 0
            // Building Type 1
            int Loop0Start = 1;
            for (int i0 = Loop0Start; i0 < BUILDN; i0++)
            {
                // Loop for Allocation Percent options
                for (int opt0 = 0; opt0 < options; opt0++)
                {
                    {   // SetSCope
                        // calculate allocation percent for each 
                        double AllocateEach = Allocate[opt0] / ((i0 - Loop0Start)+1);
                        //loop through my allocations
                        ZeroOut(Allocations[0]);
                        for (int j = Loop0Start; j < i0 + 1; j++)
                        {
                            Allocations[0][j] = AllocateEach;
                        }
                        Allocations[0][TOTALALLOCATION] = Allocate[opt0];
                    }
                    // loop 1
                    // Building Type 2
                    int Loop1Start = 2;
                    for (int i1 = Loop1Start; i1 < BUILDN; i1++)
                    {

                        // Loop for Allocation Percent options
                        for (int opt1 = 0; opt1 < options; opt1++)
                        {
                            {   // SetSCope
                                // calculate allocation percent
                                double AllocateEach = Allocate[opt1] / ((i1 - Loop1Start)+1);
                                //loop through my allocations
                                ZeroOut(Allocations[1]);
                                for (int j = Loop1Start; j < i1 + 1; j++)
                                {
                                    Allocations[1][j] = AllocateEach;
                                }
                                Allocations[1][TOTALALLOCATION] = Allocate[opt1];
                            }

                            // loop 2
                            //  Building Type 3
                            //
                            int Loop2Start = 3;
                            for (int i2 = Loop2Start; i2 < BUILDN; i2++)
                            {
                                for (int opt2 = 0; opt2 < options; opt2++)
                                {
                                    {   // SetSCope
                                        // calculate allocation percent
                                        double AllocateEach = Allocate[opt2] / ((i2 - Loop2Start) + 1);
                                        //loop through my allocations
                                        ZeroOut(Allocations[2]);
                                        for (int j = Loop2Start; j < i2 + 1; j++)
                                        {
                                            Allocations[2][j] = AllocateEach;
                                        }
                                        Allocations[2][TOTALALLOCATION] = Allocate[opt2];
                                    }

                                    // loop 3
                                    //  Building Type 4
                                    //
                                    int Loop3Start = 4;
                                    for (int i3 = Loop3Start; i3 < BUILDN; i3++)
                                    {
                                        for (int opt3 = 0; opt3 < options; opt3++)
                                        {
                                            {   // SetSCope
                                                // calculate allocation percent
                                                double AllocateEach = Allocate[opt3] / ((i3 - Loop3Start) + 1);
                                                //loop through my allocations
                                                ZeroOut(Allocations[3]);
                                                for (int j = Loop3Start; j < i3 + 1; j++)
                                                {
                                                    Allocations[3][j] = AllocateEach;
                                                }
                                                Allocations[3][TOTALALLOCATION] = Allocate[opt3];
                                            }

                                            // loop 4
                                            //  Building Type 5
                                            //
                                            int Loop4Start = 5;
                                            for (int i4 = Loop4Start; i4 < BUILDN; i4++)
                                            {
                                                for (int opt4 = 0; opt4 < options; opt4++)
                                                {
                                                    {   // SetSCope
                                                        // calculate allocation percent
                                                        double AllocateEach = Allocate[opt4] / ((i4 - Loop4Start) + 1);
                                                        //loop through my allocations
                                                        ZeroOut(Allocations[4]);
                                                        for (int j = Loop4Start; j < i4 + 1; j++)
                                                        {
                                                            Allocations[4][j] = AllocateEach;
                                                        }
                                                        Allocations[4][TOTALALLOCATION] = Allocate[opt4];
                                                    }

                                                    // loop 5
                                                    //  Building Type 6
                                                    //
                                                    int Loop5Start = 6;
                                                    for (int i5 = Loop5Start; i5 < BUILDN; i5++)
                                                    {
                                                        for (int opt5 = 0; opt5 < options; opt5++)
                                                        {
                                                            {   // SetSCope
                                                                // calculate allocation percent
                                                                double AllocateEach = Allocate[opt5] / ((i5 - Loop5Start)+1);
                                                                //loop through my allocations
                                                                ZeroOut(Allocations[5]);
                                                                for (int j = Loop5Start; j < i5 + 1; j++)
                                                                {
                                                                    Allocations[5][j] = AllocateEach;
                                                                }
                                                                Allocations[5][TOTALALLOCATION] = Allocate[opt5];
                                                            }


                                                            // THE HEART!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                                                            
                                                            // create scenario
                                                            string Sname = "SCN_"+count.ToString();
                                                            DemandScenario DS = new DemandScenario(Sname);
                                                            
                                                            // OK cycle through all values
                                                            for (int BTIndex = 0; BTIndex < 7; BTIndex++)
                                                            {
                                                                // OK, create the base condition
                                                                double PersonsPerHH = BuildList[BTIndex].HouseholdSize;
                                                                double IndoorGPCD = BuildList[BTIndex].IndoorGPCD;
                                                                string HouseName = Sname + "_BT" + BTIndex.ToString() + "B";
                                                                double BaseHouseHolds = BaseScenarioData.BaseUnits_2010[BTIndex];
                                                                double GrowthHouseHolds = BaseScenarioData.GrowthUnits_2040[BTIndex];
                                                                double HouseHoldsLeft = BaseHouseHolds + (GrowthHouseHolds * (1- Allocations[BTIndex][TOTALALLOCATION]));
                                                                HouseHoldWaterDemand HHWD = new HouseHoldWaterDemand(BuildList[BTIndex].Code, HouseName, "", BuildList[BTIndex], PersonsPerHH, HouseHoldsLeft, IndoorGPCD);
                                                                DS.Add(HHWD);
                                                                for (int AllocateIndex = 0; AllocateIndex < TOTALALLOCATION; AllocateIndex++)
                                                                {
                                                                    if (Allocations[BTIndex][AllocateIndex] > 0)
                                                                    {
                                                                        // create Household Agent for this scenario
                                                                        HouseName = Sname + "_BT" + BTIndex.ToString() + "_" + Allocations[BTIndex][AllocateIndex].ToString();
                                                                        double AllocatedUnits = GrowthHouseHolds * Allocations[BTIndex][AllocateIndex];
                                                                        HHWD = new HouseHoldWaterDemand(BuildList[AllocateIndex].Code, HouseName, "", BuildList[AllocateIndex], PersonsPerHH, AllocatedUnits, IndoorGPCD);
                                                                        DS.Add(HHWD);
                                                                        testcnt++;
                                                                    }
                                                                }

                                                            }
                                                            count++;
                                                            DSL.Add(DS);
                                                            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                                                        } // opt 5
                                                    } // i5
                                                } // opt4
                                            }  // i4
                                        } // opt3
                                    }  // i3
                                } // opt2
                            }  //i2
                        } // opt1
                    } // i1
                } //opt0
            } // i0 
            return DSL;
        }
    }

    /// <summary>   Data for Base scenario. </summary>
    public class BaseScenario
    {
        double[] UnitsByBuildingType_2010 = new double[7] ;
        double[] UnitsByBuildingType_Growth_2040 = new double[7];
        double[] PeopleByBuildingType_2010 = new double[7];
        double[] PeopleByBuildingType_Growth_2040 = new double[7];
         
        public BaseScenario(BuildingTypeList BuildingTypes)
        {
         UnitsByBuildingType_2010[0] = 131614;
         UnitsByBuildingType_2010[1] = 448128;
         UnitsByBuildingType_2010[2] =  53621;
         UnitsByBuildingType_2010[3] =  39209;
         UnitsByBuildingType_2010[4] =  50746;
         UnitsByBuildingType_2010[5] =  13911;
         UnitsByBuildingType_2010[6] =   8198;

         UnitsByBuildingType_Growth_2040[0] =  99240;
         UnitsByBuildingType_Growth_2040[1] =   337899;
         UnitsByBuildingType_Growth_2040[2] =   40431;
         UnitsByBuildingType_Growth_2040[3] =	29564;
         UnitsByBuildingType_Growth_2040[4] =	38264;
         UnitsByBuildingType_Growth_2040[5] =	10489;
         UnitsByBuildingType_Growth_2040[6] =	6182 ;
    
         for(int i=0; i<7; i++)
         {
             PeopleByBuildingType_2010[i] = BuildingTypes[i].HouseholdSize * UnitsByBuildingType_2010[i];
             PeopleByBuildingType_Growth_2040[i] = BuildingTypes[i].HouseholdSize * UnitsByBuildingType_Growth_2040[i];    
         }
        }

        public double[] BaseUnits_2010
        {
            get { return UnitsByBuildingType_2010; }
        }

        public double[] GrowthUnits_2040
        {
            get { return UnitsByBuildingType_Growth_2040; }
        }


    }

   
 
    public class DemandScenario
    {
        string FName = "";
        List<HouseHoldWaterDemand> FHHData = new List<HouseHoldWaterDemand>();
        public DemandScenario(string Name)
        {
            FName = Name;
        }

        public List<HouseHoldWaterDemand> HouseholdList
        {
            get { return FHHData; }
        }

        public void Add(HouseHoldWaterDemand Household)
        {
            FHHData.Add(Household);
        }

        public void AddData(DenverHouseholdData HouseholdData)
        {
            FHHData.Add(HouseholdData.NewHousehold());
        }

    }


    public class DemandScenarioList : List<DemandScenario>
    {
        public DemandScenarioList()
            : base()
        {
        }


    }

}
