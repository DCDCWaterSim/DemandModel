﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using UniDB;
using System.IO;

namespace BuildingTypes
{
    public class BuildingType
    {
        public const int RangeLow = 0;
        public const int RangeMedian = 1;
        public const int RangeHigh = 2;

        const int RangeSize = 3;

        string FCode = "Res";
        string FName = "Residential";  // default
        
      
        double FDUA = 3.0;
        double FGPSF = 5;          // Default Seasonal Gallons Per SqFt Pervious Surface
        double FIndoorGPCD = 25;
        double PA_BaseFactor = 30001;       // Slope Intercept for pervious surface function
        double PA_Exponent = -1.167;       // Exponent for pervious surface function
        double[] FDUA_Range = new double[RangeSize] { 0.2,2.8,4.0}; // Low Median High  of Dwelling Uniots Per Acre With Defaults
        double[] FGPSF_Range = new double[RangeSize] { 1.4 ,11.9,22.5}; // Low Median High Range of  Seasonal Gallons Per SqFt Pervious Surface with defaults
        double[] FIndoorGPCDRange = new double[RangeSize] { 25, 25, 25 };  // Low Median High Indoor GOCD

        double FHHSize = 0.0;

        public BuildingType()
        {
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <remarks>   Ray Quay, 3/16/2017. </remarks>
        ///
        /// <param name="aCode">    The code. </param>
        /// <param name="aName">    The name. </param>

        public BuildingType(string aCode, string aName)
        {
            FCode = aCode;
            FName = aName;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="aCode">            The code. </param>
        /// <param name="aName">            The name. </param>
        /// <param name="DUA">              The dua. </param>
        /// <param name="DUA_Range">        The dua range. </param>
        /// <param name="GPSFP">            The gpsfp. </param>
        /// <param name="GPSFP_Range">      The gpsfp range. </param>
        /// <param name="theHouseholdSize"> Size of the household. </param>
        ///-------------------------------------------------------------------------------------------------
        
        public BuildingType(string aCode, string aName, double DUA, double[] DUA_Range, double GPSFP, double[] GPSFP_Range, double theHouseholdSize)
        {
            FCode = aCode;
            FName = aName;
            FDUA = DUA;
            FGPSF = GPSFP;
            FHHSize = theHouseholdSize;

            if (DUA_Range.Length > RangeSize - 1)
            {
                for (int i = 0; i < RangeSize; i++)
                {
                    FDUA_Range[i] = DUA_Range[i];
                }
            }
            if (GPSFP_Range.Length > RangeSize - 1)
            {
                for (int i = 0; i < RangeSize; i++)
                {
                    FGPSF_Range[i] = GPSFP_Range[i];
                }
            }

        }

        public BuildingType(string aCode, string aName, double DUA, double[] DUA_Range, double GPSFP, double[] GPSFP_Range, double theHouseholdSize, double IndoorGPCD, double[] IndoorGPCDRange)
        {
            FCode = aCode;
            FName = aName;
            FDUA = DUA;
            FGPSF = GPSFP;
            FHHSize = theHouseholdSize;
            FIndoorGPCD = IndoorGPCD;
            if (DUA_Range.Length > RangeSize - 1)
            {
                for (int i = 0; i < RangeSize; i++)
                {
                    FDUA_Range[i] = DUA_Range[i];
                }
            }
            if (GPSFP_Range.Length > RangeSize - 1)
            {
                for (int i = 0; i < RangeSize; i++)
                {
                    FGPSF_Range[i] = GPSFP_Range[i];
                }
            }
            if (IndoorGPCDRange.Length > RangeSize - 1)
            {
                for (int i = 0; i < RangeSize; i++)
                {
                    FIndoorGPCDRange[i] = IndoorGPCDRange[i];
                }
            }

        }


        //==================================
        //Properties
        //==================================

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the code. </summary>
        ///
        /// <value> The code. </value>

        public string Code
        {
            get { return FCode; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the name. </summary>
        ///
        /// <value> The name. </value>

        public string Name
        {
            get { return FName; }
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the dwellin units per acre. </summary>
        ///
        /// <value> The dwellin units per acre. </value>

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the dwellin units per ac </summary>
        ///
        /// <value> The dwellin units per acre. </value>

        public double DwellinUnitsPerAcre
        {
            get { return FDUA; }
            set { FDUA = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the gallons per sq ft pervious. </summary>
        ///
        /// <value> The gallons per sq ft pervious. </value>

        public double GallonsPerSqFtPervious
        {
            get { return FGPSF; }
            set { FGPSF = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the dwelling units per acre range. </summary>
        /// <remarks>   If the length of value array is less than RangeSize, values npt set, if laregeer only up to Rnage size -1 is set</remarks>
        /// <value> The dwelling units per acre range. </value>

        public double[] DwellingUnitsPerAcre_Range
        {
            get { return FDUA_Range; }
            set
            {
                if (value.Length > RangeSize-1)
                {
                    for (int i = 0; i < RangeSize; i++)
                    {
                        FDUA_Range[i] = value[i];
                    }
                }
            }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the gallans per sq ft pervious range. </summary>
        /// <remarks>   If the length of value array is less than RangeSize, values npt set, if laregeer only up to Rnage size -1 is set</remarks>
        ///
        /// <value> The gallans per sq ft pervious range. </value>

        public double [] GallansPerSqFtPervious_Range
        {
            get { return FGPSF_Range; }
            set
            {
                if (value.Length > RangeSize - 1)
                {
                    for (int i = 0; i < RangeSize; i++)
                    {
                        FGPSF_Range[i] = value[i];
                    }
                }
            }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the size of the household. </summary>
        ///
        /// <value> The size of the household. </value>
        ///-------------------------------------------------------------------------------------------------

        public double HouseholdSize
        {
            get {return FHHSize; }
            set {FHHSize = value;}
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the indoor gpcd. </summary>
        ///
        /// <value> The indoor gpcd. </value>
        ///-------------------------------------------------------------------------------------------------

        public double IndoorGPCD
        {
            get { return FIndoorGPCD; }
            set { FIndoorGPCD = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the indoor gpcd range. </summary>
        ///
        /// <value> The indoor gpcd range. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] IndoorGPCDRange
        {
            get { return FIndoorGPCDRange; }
            set { FIndoorGPCDRange = value; }
        }

        //==================================
        // BASE METHODS
        //================================


        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Estimated pervious sq ft per dwelling unit. </summary>
        /// <returns>   A double. </returns>

        public double EstimatedPerviousSqFtPerDwellingUnit()
        {
            double result = 0;
            // Denver Pervious Area Equation
            result = PA_BaseFactor * Math.Pow(FDUA, PA_Exponent);
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Sets dwelling u nits per acre. </summary>
        /// <remarks>    If outside range 0 to RangeSize-1, value not set</remarks>
        /// <param name="RangeIndex">   Zero-based index of the range. </param>

        public void SetDwellingUnitsPerAcre(int RangeIndex)
        {
            if ((RangeIndex > -1) && (RangeIndex < RangeSize))
            {
                FDUA = FDUA_Range[RangeIndex];
            }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Sets gallons per square foot. </summary>
        /// <remarks>    If outside range 0 to RangeSize-1, value not set</remarks>
        /// <param name="RangeIndex">   Zero-based index of the range. </param>

        public void SetGallonsPerSquareFoot(int RangeIndex)
        {
            if ((RangeIndex > -1) && (RangeIndex < RangeSize))
            {
                FGPSF = FGPSF_Range[RangeIndex];
            }
        }


    }

    //====================================================================================

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   List of building types. </summary>
    ///
    ///-------------------------------------------------------------------------------------------------

    public class BuildingTypeList : List<BuildingType>
    {
        BuildingTypeData FBData = null;

        public BuildingTypeList(string filename) : base()
        {
            try
            {
                FBData = new BuildingTypeData(filename);
                AssignData();
            }
            catch (Exception ex)
            {
                throw ex;
            }   
        }

        private void AssignData()
        {
            int RecCnt = FBData.Count;
            for (int BTi = 0; BTi<RecCnt; BTi++)

           {
               string theCode = FBData.TypeCodes[BTi];
               string theName = FBData.TypeLabels[BTi];
               double theDUA = FBData.DwellingUnitsPerAcre[BTi];
               double[] theDUARange = FBData.DUA_Range[BTi];
               double theGSF = FBData.SeasonalGPSF[BTi];
               double[] theGSFRange = FBData.SeasonalGPSF_Range[BTi];
               double TheHHSize = FBData.PersonsPerHousehold[BTi];
               double TheIGPCD = FBData.IndoorGPCD[BTi];
               double[] TheIGPCDRange = FBData.IndoorGPCD_Range[BTi];
               BuildingType BT = new BuildingType(theCode, theName, theDUA, theDUARange, theGSF, theGSFRange, TheHHSize,TheIGPCD,TheIGPCDRange);

               this.Add(BT);
           }
        }

        public BuildingType FindByCode(string Code)
        {
            return this.Find(delegate(BuildingType BT) { return BT.Code == Code; });
        }

     }

    //====================================================================================

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   A building type data. </summary>
    ///
    ///-------------------------------------------------------------------------------------------------

    public class BuildingTypeData
    {

        // CONSTANTS
        const double BADVALUE = double.NaN;

        // DataTable
        DataTable FBuildingData;

        // Column Info
        const int BFieldCount = 18;

        int BTypeCode = 0;     // Building Type Code
        int BType = 1;          // Building Type
        int PPHH = 2;           // Persons Per Household
        int IGPCD = 3;          // Default Indoor Gallons Per Capita per Day
        int DUA = 4;            // Default Dweling Units Per Acre
        int SGPSF = 5;          // Default Seasonal Gallons Per SqFt Pervious Surface
        int DummyInt = 6;       // Slope Intercept for pervious surface function
        int DummyExp = 7;       // Exponent for pervious surface function
        int DefaultPOP = 8;     // Default population
        int IGPCD_Hi = 9;       // High end of Indoor Gallons Per Capita per Day
        int IGPCD_Mn = 10;       // Mean or Median of Indoor Gallons Per Capita per Day
        int IGPCD_Lo = 11;       // Low end of Indoor Gallons Per Capita per Day
        int DUA_Hi = 12;         // High end of Dwelling Uniots Per Acre
        int DUA_Mn = 13;         // Mean or Median of Dwelling Uniots Per Acre
        int DUA_Lo = 14;         // Low end of Dwelling Uniots Per Acre
        int SGPSF_Hi = 15;       // High End of Seasonal Gallons Per SqFt Pervious Surface
        int SGPSF_Mn = 16;       // Mean or Median of Seasonal Gallons Per SqFt Pervious Surface
        int SGPSF_Lo = 17;       // Low end of Seasonal Gallons Per SqFt Pervious Surface    

        string[] FBFieldnames = new string[BFieldCount] { 
        "BTypeCode"     // Building Type Code
        ,"Btype"         // Building Type
        ,"PPHH"          // Persons Per Household
        ,"IGPCD"         // Default Indoor Gallons Per Capita per Day
        ,"DUA"           // Default Dweling Units Per Acre
        ,"SGPSF"         // Default Seasonal Gallons Per SqFt Pervious Surface
        ,"DummyInt"      // Slope Intercept for pervious surface function
        ,"DummyExp"      // Exponent for pervious surface function
        ,"DefaultPOP"    // Default population
        ,"IGPCD_Hi"      // High end of Indoor Gallons Per Capita per Day
        ,"IGPCD_Mn"      // Mean or Median of Indoor Gallons Per Capita per Day
        ,"IGPCD_Lo"      // Low end of Indoor Gallons Per Capita per Day
        ,"DUA_Hi"        // High end of Dwelling Uniots Per Acre
        ,"DUA_Mn"        // Mean or Median of Dwelling Uniots Per Acre
        ,"DUA_Lo"        // Low end of Dwelling Uniots Per Acre
        ,"SGPSF_Hi"      // High End of Seasonal Gallons Per SqFt Pervious Surface
        ,"SGPSF_Mn"      // Mean or Median of Seasonal Gallons Per SqFt Pervious Surface
        ,"SGPSF_Lo"      // Low end of Seasonal Gallons Per SqFt Pervious Surface    
        };

        string[] FBFieldLabels = new string[BFieldCount] { 
        "Building Type Code", 
        "Building Type"
        ,"Persons Per Household"
        ,"Default Indoor Gallons Per Capita per Day"
        ,"Default Dweling Units Per Acre"
        ,"Default Seasonal Gallons Per SqFt Pervious Surface"
        ,"Slope Intercept for pervious surface function"
        ,"Exponent for pervious surface function"
        ,"Default population"
        ,"High end of Indoor Gallons Per Capita per Day"
        ,"Mean or Median of Indoor Gallons Per Capita per Day"
        ,"Low end of Indoor Gallons Per Capita per Day"
        ,"High end of Dwelling Uniots Per Acre"
        ,"Mean or Median of Dwelling Uniots Per Acre"
        ,"Low end of Dwelling Uniots Per Acre"
        ,"High End of Seasonal Gallons Per SqFt Pervious Surface"
        ,"Mean or Median of Seasonal Gallons Per SqFt Pervious Surface"
        ,"Low end of Seasonal Gallons Per SqFt Pervious Surface"
        };

        // Name Lists
        List<string> FBuildingTypes = new List<string>();
        List<string> FBuildingTypeCodes = new List<string>();

        // Data

        string[] FTypeCodes;
        string[] FTypeLabels;
        double[] FPopulation;
        double[] FPersonsPerHousehold;
        double[] FIndoorGPCD;
        double[] FDwellingUnitsPerAcre;
        double[] FSeasonalGPSF;
        double[] FPerviousIntercept;
        double[] FPerviousExponent;

        double[][] FIndoorGPCD_Range;
        double[][] FDUA_Range;
        double[][] FSeasonalGPSF_Range;

        int FCount = 0;
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <exception cref="Exception">    Thrown when error reading building data. </exception>
        ///
        /// <param name="DataFilename"> Filename of the data file. </param>
        ///-------------------------------------------------------------------------------------------------

        public BuildingTypeData(string DataFilename)
        {
            bool isErr = false;
            string errMsg = "";
            // split out the path and fieldname
            string dbPath = Path.GetDirectoryName(DataFilename);
            string dbTablename = Path.GetFileName(DataFilename);
            if (dbPath != "")
            {
                // Create the DbConnection
                UniDbConnection DBCon = new UniDbConnection(SQLServer.stText, "", dbPath, "", "", "");
                try
                {
                    // Open and load table
                    DBCon.Open();
                    DBCon.UseFieldHeaders = true;
                    FBuildingData = Tools.LoadTable(DBCon, dbTablename, ref isErr, ref errMsg);
                    // if err throw exception
                    if (isErr)
                    {
                        throw new Exception("Error reading data: " + errMsg);
                    }
                    // check to seen if all the required fields are here
                    isErr = false;
                    errMsg = "";
                    foreach (string Fldstr in FBFieldnames)
                    {
                        if (!FBuildingData.Columns.Contains(Fldstr))
                        {
                            isErr = true;
                            errMsg += Fldstr + ",";
                        }
                    }
                    // if field missing throw exception
                    if (isErr)
                    {
                        throw new Exception("Error Loading Data : Required fields " + errMsg + " are missing!");
                    }
                    // Build the Lists
                    BuildTypeLists();
                    // Assign all values from datatable
                    assignValues();

                }
                catch (Exception ex)
                {
                    throw new Exception("Error Creating BuildingDemandData: " + ex.Message);
                }
            }
        }

        private void BuildTypeLists()
        {
            FBuildingTypeCodes.Clear();
            FBuildingTypes.Clear();
            foreach (DataRow DR in FBuildingData.Rows)
            {
                string Code = DR[FBFieldnames[BTypeCode]].ToString();
                FBuildingTypeCodes.Add(Code);
                string Name = DR[FBFieldnames[BType]].ToString();
                FBuildingTypes.Add(Name);
            }
        }

        private double ConvertDouble(string ValueStr)
        {
            double result;
            bool isErr = false;
            string errMsg = "";

            double temp = Tools.ConvertToDouble(ValueStr, ref isErr, ref errMsg);
            if (!isErr)
            {
                result = temp;
            }
            else
            {
                result = BADVALUE;
            }
            return result;

        }

        /// <summary>   Assign values. </summary>
        protected void assignValues()
        {
            // Setup
            int BTypeNumber = FBuildingData.Rows.Count;
            FCount = BTypeNumber;

            FTypeCodes = new string[BTypeNumber];
            FTypeLabels = new string[BTypeNumber];
            FPopulation = new double[BTypeNumber];
            FPersonsPerHousehold = new double[BTypeNumber];
            FIndoorGPCD = new double[BTypeNumber];
            FDwellingUnitsPerAcre = new double[BTypeNumber];
            FSeasonalGPSF = new double[BTypeNumber];
            FPerviousIntercept = new double[BTypeNumber];
            FPerviousExponent = new double[BTypeNumber];

            FIndoorGPCD_Range = new double[BTypeNumber][];
            FDUA_Range = new double[BTypeNumber][];
            FSeasonalGPSF_Range = new double[BTypeNumber][];
            // Assign Sub Cells
            for (int i = 0; i < BTypeNumber; i++)
            {
                FIndoorGPCD_Range[i] = new double[3];
                FDUA_Range[i] = new double[3];
                FSeasonalGPSF_Range[i] = new double[3];

            }

            // TypeCodes and labels
            for (int i = 0; i < BTypeNumber; i++)
            {
                FTypeCodes[i] = FBuildingTypeCodes[i];
                FTypeLabels[i] = FBuildingTypes[i];
            }
            // go through database, assign values
            int RecNum = 0;
            foreach (DataRow DR in FBuildingData.Rows)
            {
                FPopulation[RecNum] = ConvertDouble(DR[FBFieldnames[DefaultPOP]].ToString());
                FPersonsPerHousehold[RecNum] = ConvertDouble(DR[FBFieldnames[PPHH]].ToString());
                FIndoorGPCD[RecNum] = ConvertDouble(DR[FBFieldnames[IGPCD]].ToString());
                FDwellingUnitsPerAcre[RecNum] = ConvertDouble(DR[FBFieldnames[DUA]].ToString());
                FSeasonalGPSF[RecNum] = ConvertDouble(DR[FBFieldnames[SGPSF]].ToString());
                FPerviousIntercept[RecNum] = ConvertDouble(DR[FBFieldnames[DummyInt]].ToString());
                FPerviousExponent[RecNum] = ConvertDouble(DR[FBFieldnames[DummyExp]].ToString());

                FIndoorGPCD_Range[RecNum][0] = ConvertDouble(DR[FBFieldnames[IGPCD_Lo]].ToString());
                FIndoorGPCD_Range[RecNum][1] = ConvertDouble(DR[FBFieldnames[IGPCD_Mn]].ToString());
                FIndoorGPCD_Range[RecNum][2] = ConvertDouble(DR[FBFieldnames[IGPCD_Hi]].ToString());
                FDUA_Range[RecNum][0] = ConvertDouble(DR[FBFieldnames[DUA_Lo]].ToString());
                FDUA_Range[RecNum][1] = ConvertDouble(DR[FBFieldnames[DUA_Mn]].ToString());
                FDUA_Range[RecNum][2] = ConvertDouble(DR[FBFieldnames[DUA_Hi]].ToString());
                FSeasonalGPSF_Range[RecNum][0] = ConvertDouble(DR[FBFieldnames[SGPSF_Lo]].ToString());
                FSeasonalGPSF_Range[RecNum][1] = ConvertDouble(DR[FBFieldnames[SGPSF_Mn]].ToString());
                FSeasonalGPSF_Range[RecNum][2] = ConvertDouble(DR[FBFieldnames[SGPSF_Hi]].ToString());

                RecNum++;
            }

        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the information describing the building. </summary>
        ///
        /// <value> Information describing the building. </value>
        ///-------------------------------------------------------------------------------------------------

        public DataTable BuildingData
        {
            get { return FBuildingData; }
        }

        public int Count
        {
            get { return FCount; }
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the type codes. </summary>
        ///
        /// <value> The type codes. </value>
        ///-------------------------------------------------------------------------------------------------

        public string[] TypeCodes
        { get { return FTypeCodes; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the type labels. </summary>
        ///
        /// <value> The type labels. </value>
        ///-------------------------------------------------------------------------------------------------

        public string[] TypeLabels
        { get { return FTypeLabels; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the population. </summary>
        ///
        /// <value> The population. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] Population
        { get { return FPopulation; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the persons per household. </summary>
        ///
        /// <value> The persons per household. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] PersonsPerHousehold
        { get { return FPersonsPerHousehold; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the indoor gpcd. </summary>
        ///
        /// <value> The indoor gpcd. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] IndoorGPCD
        { get { return FIndoorGPCD; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the dwelling units per acre. </summary>
        ///
        /// <value> The dwelling units per acre. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] DwellingUnitsPerAcre
        { get { return FDwellingUnitsPerAcre; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the seasonal gpsf. </summary>
        ///
        /// <value> The seasonal gpsf. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] SeasonalGPSF
        { get { return FSeasonalGPSF; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the pervious intercept. </summary>
        ///
        /// <value> The pervious intercept. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] PerviousIntercept
        { get { return FPerviousIntercept; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the pervious exponent. </summary>
        ///
        /// <value> The pervious exponent. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[] PerviousExponent
        { get { return FPerviousExponent; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the indoor gpcd range. </summary>
        ///
        /// <value> The indoor gpcd range. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[][] IndoorGPCD_Range
        { get { return FIndoorGPCD_Range; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the dua range. </summary>
        ///
        /// <value> The dua range. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[][] DUA_Range
        { get { return FDUA_Range; } }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the seasonal gpsf range. </summary>
        ///
        /// <value> The seasonal gpsf range. </value>
        ///-------------------------------------------------------------------------------------------------

        public double[][] SeasonalGPSF_Range
        { get { return FSeasonalGPSF_Range; } }

    }

}
