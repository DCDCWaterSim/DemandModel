﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemandAgentClass
{
    // =====================================================
    // Exception Classes
    // ======================================================
    #region Exception Classes

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   Exception for signalling agent errors. </summary>
    ///
    /// <seealso cref="System.Exception"/>
    ///-------------------------------------------------------------------------------------------------

    public class AgentException : Exception
    {
        public AgentException(string aMessage)
            : base("Agent:" + aMessage)
        {
        }
    }

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   Exception for signalling agent model errors. </summary>
    ///
    /// <seealso cref="System.Exception"/>
    ///-------------------------------------------------------------------------------------------------

    public class AgentModelException : Exception
    {
        public AgentModelException(string aMessage)
            : base("Model:" + aMessage)
        {
        }
    }

    #endregion Exception Classes


    //====================================================
    // Beahvior Classes
    // ===================================================

    #region AgentBehavior

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   An agent behavior class. </summary>
    ///
    ///-------------------------------------------------------------------------------------------------

    public abstract class AgentBehaviorClass
    {
        int FBehaviorCode = 0;
        string FName = 0;
        DemandAgent FOwner = null;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <remarks>   3/7/2017. </remarks>
        ///
        /// <param name="TheBehaviorCode">  the behavior code. </param>
        /// <param name="TheBeahviorName">  Name of the beahvior. </param>
        /// <param name="Owner">            The owner. </param>
        ///-------------------------------------------------------------------------------------------------

        public AgentBehaviorClass(int TheBehaviorCode, string TheBeahviorName, DemandAgent Owner)
        {
            FBehaviorCode = TheBehaviorCode;
            FName = TheBeahviorName;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the behavior code. </summary>
        ///
        /// <value> The behavior code. </value>
        ///-------------------------------------------------------------------------------------------------

        public int BehaviorCode
        {
            get { return FBehaviorCode; } 
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the owner. </summary>
        ///
        /// <value> The owner. </value>
        ///-------------------------------------------------------------------------------------------------

        public DemandAgent Owner
        {
            get {return FOwner; }
        }

        public string Name
        {
            get { return FName; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Method for Behavior Action. </summary>
        ///
        ///-------------------------------------------------------------------------------------------------

        public abstract void  Act()
        {

        }
    }

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   An agent behavior list class. </summary>
    ///-------------------------------------------------------------------------------------------------

    public class AgentBehaviorListClass : List<AgentBehaviorClass>
    {
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Findby code. </summary>
        ///
        /// <param name="aCode">    The code. </param>
        ///
        /// <returns>   The AgentBehaviorClass. </returns>
        ///-------------------------------------------------------------------------------------------------

        public AgentBehaviorClass FindbyCode(int aCode)
        {
            AgentBehaviorClass Temp = this.Find(delegate(AgentBehaviorClass AB) { return AB.BehaviorCode == aCode; });
            return Temp;
        }
    }

    #endregion AgentBehavior


    //=====================================================
    // Demand Agent Class
    // ====================================================
     
    /// <summary>   Demand agent. 
    ///             This is the base Demand Agent Class</summary>
    class DemandAgent
    {
		// Identifiers
        protected string FTypeCode = "";
        protected string FTypeLabel = "";
		protected string FName = "";
		// Demand Results
        protected double FIndoorDemand = 0;
        protected double FOutdoorDemand = 0;
        protected double FOtherDemand = 0;
        protected double FAnnualDemand = 0;

        AgentBehaviorListClass FBehaviorList = new AgentBehaviorListClass();

        /// <summary>   Default constructor. </summary>
		public DemandAgent()
        {

        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="aTypeCode">    The type code. </param>
        /// <param name="aTypeLabel">   The type label. </param>
        ///-------------------------------------------------------------------------------------------------

        public DemandAgent(string aTypeCode, string aTypeLabel)
        {
            FTypeCode = aTypeCode;
            FTypeLabel = aTypeLabel;
			Guid MYGUID = Guid.NewGuid();
			FName = MYGUID.ToString("X");
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="aTypeCode">    The type code. </param>
        /// <param name="aTypeLabel">   The type label. </param>
        /// <param name="aName">        The name. This must be a unique name for all agents used</param>
        ///-------------------------------------------------------------------------------------------------

        public DemandAgent(string aTypeCode, string aTypeLabel, string aName)
        {
            FTypeCode = aTypeCode;
            FTypeLabel = aTypeLabel;
			FName = aName;
        }
        //==================================================================
        // Operation Methods
        // =================================================================

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Estimated demand. </summary>
        ///
        /// <param name="year"> The year. </param>
        ///-------------------------------------------------------------------------------------------------

        public virtual void EstimateDemand(int year)
        {
            FAnnualDemand = FIndoorDemand + FOutdoorDemand + FOtherDemand;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Recieve message
        ///             This method allows messages and data to be communicated between Agents. </summary>
        ///
        ///
        /// <param name="aDemandAgent"> The demand agent. </param>
        /// <param name="MessageCode">  The message code. </param>
        /// <param name="aValue">       The value being sent. </param>
        ///
        /// <returns>   An int. 0 means message is NOT acknowledged, >0 means message acknowledge</returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual int RecieveMessage(DemandAgent aDemandAgent, int MessageCode, double aValue)
        {
            int result = 0;
            // DO Soemthing
             
            // acknowledge message
            result = 1;

            return result;
        }

        public void AddBehavior(AgentBehaviorClass aBehavior)
        {
            BehaviorList.Add(aBehavior);
        }
        //====================================================================
        // Properties
        // ===================================================================

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the type code. </summary>
        ///
        /// <value> The type code. </value>
        ///-------------------------------------------------------------------------------------------------

        public string TypeCode
        {
            get { return FTypeCode; }
            set { FTypeCode = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the type label. </summary>
        ///
        /// <value> The type label. </value>
        ///-------------------------------------------------------------------------------------------------

        public string TypeLabel
        {
            get { return FTypeLabel; }
            set { FTypeLabel = value; }
        }

		public string UniqueName
        {
			get { return FName; }
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the annual demand. </summary>
        ///
        /// <value> The annual demand. </value>
        ///-------------------------------------------------------------------------------------------------

        public virtual double AnnualDemand
        {
            get { return FAnnualDemand; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the indoor demand. </summary>
        ///
        /// <value> The indoor demand. </value>
        ///-------------------------------------------------------------------------------------------------

        public virtual double IndoorDemand
        {
            get { return FIndoorDemand; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the outdoor demand. </summary>
        ///
        /// <value> The outdoor demand. </value>
        ///-------------------------------------------------------------------------------------------------

        public virtual double OutdoorDemand
        {
            get { return FOutdoorDemand; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the other demand. </summary>
        ///
        /// <value> The other demand. </value>
        ///-------------------------------------------------------------------------------------------------

        public virtual double OtherDemand
        {
            get { return FOtherDemand; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets a list of behaviors. </summary>
        ///
        /// <value> A List of behaviors. </value>
        ///-------------------------------------------------------------------------------------------------

        public AgentBehaviorListClass BehaviorList
        {
            get { return FBehaviorList; }
        }


    }

	//=========================================================================================
    /// <summary>   Demand model. 
    ///             This is the base Demand Model class, ie the playground for demand agents</summary>
    class DemandAgentModel
    {
		// The Players, a list of agents
		List<DemandAgent> FDemandAgentList = new List<DemandAgent>();

        double FTotalAnnualDemand = 0;
        double FTotalIndoorDemand = 0;
        double FTotalOutdoorDemand = 0;

        /// <summary>   Default constructor. </summary>
        public DemandAgentModel()
        {
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Adds a demand agent. </summary>
        ///
        /// <param name="TheAgent"> the agent. </param>
        ///-------------------------------------------------------------------------------------------------

		public void AddDemandAgent(DemandAgent TheAgent)
        {
			FDemandAgentList.Add(TheAgent);
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Searches for the first agent with Unique ID
        ///
        /// <param name="UniqueName">   Name of the unique. </param>
        ///
        /// <returns>   The found agent. </returns>
        ///-------------------------------------------------------------------------------------------------

        public DemandAgent FindAgent(string UniqueName)
        {
            DemandAgent Temp = FDemandAgentList.Find(delegate(DemandAgent DA) { return DA.UniqueName == UniqueName; });
            return Temp;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Searches for the first agents. </summary>
        ///
        /// <param name="TypeCode"> The type code. </param>
        ///
        /// <returns>   The found agents. </returns>
        ///-------------------------------------------------------------------------------------------------

        public List<DemandAgent> FindAgents(string TypeCode)
        {
            List<DemandAgent> Temp = new List<DemandAgent>();
            foreach (DemandAgent DM in FDemandAgentList)
            {
                if (DM.TypeCode == TypeCode)
                    Temp.Add(DM);
            }
            return Temp;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Executes the model operation. </summary>
        ///
        /// <returns>   0 ir no errors, >0 if errors. </returns>
        ///-------------------------------------------------------------------------------------------------

        public int RunModel()
        {
            int result = 0;
            FTotalAnnualDemand = 0;
            FTotalIndoorDemand = 0;
            FTotalOutdoorDemand = 0;
            try
            {
               foreach (DemandAgent DM in FDemandAgentList)
               {
                    DM.EstimateDemand(0);
                    FTotalIndoorDemand += DM.IndoorDemand;
                    FTotalOutdoorDemand += DM.OutdoorDemand;
               }
               FTotalAnnualDemand = FTotalIndoorDemand + FTotalOutdoorDemand;
            }
            catch (Exception ex)
            {
                result = 1;
            }
            return result;
        }

    }



}
