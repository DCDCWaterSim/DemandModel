﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgentClasses
{
    // =====================================================
    // Exception Classes
    // ======================================================
    #region Exception Classes

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   Exception for signalling agent errors. </summary>
    ///
    /// <seealso cref="System.Exception"/>
    ///-------------------------------------------------------------------------------------------------

    public class AgentException : Exception
    {
        public AgentException(string aMessage)
            : base("Agent:" + aMessage)
        {
        }
    }

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   Exception for signalling agent model errors. </summary>
    ///
    /// <seealso cref="System.Exception"/>
    ///-------------------------------------------------------------------------------------------------

    public class AgentModelException : Exception
    {
        public AgentModelException(string aMessage)
            : base("Model:" + aMessage)
        {
        }
    }

    #endregion Exception Classes


    //====================================================
    // Beahvior Classes
    // ===================================================

    #region AgentBehavior

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   An agent behavior class. </summary>
    ///
    ///-------------------------------------------------------------------------------------------------

    public abstract class AgentBehaviorClass
    {
        int FBehaviorCode = 0;
        string FName = "";
        Agent FOwner = null;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <remarks>   3/7/2017. </remarks>
        ///
        /// <param name="TheBehaviorCode">  the behavior code. </param>
        /// <param name="TheBeahviorName">  Name of the beahvior. </param>
        /// <param name="Owner">            The owner. </param>
        ///-------------------------------------------------------------------------------------------------

        public AgentBehaviorClass(int TheBehaviorCode, string TheBeahviorName, Agent Owner)
        {
            FBehaviorCode = TheBehaviorCode;
            FName = TheBeahviorName;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the behavior code. </summary>
        ///
        /// <value> The behavior code. </value>
        ///-------------------------------------------------------------------------------------------------

        public int BehaviorCode
        {
            get { return FBehaviorCode; } 
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the owner. </summary>
        ///
        /// <value> The owner. </value>
        ///-------------------------------------------------------------------------------------------------

        public Agent Owner
        {
            get {return FOwner; }
        }

        public string Name
        {
            get { return FName; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Method for Behavior Action. </summary>
        ///
        ///-------------------------------------------------------------------------------------------------

        public virtual void  Act()
        {

        }
    }

    ///-------------------------------------------------------------------------------------------------
    /// <summary>   An agent behavior list class. </summary>
    ///-------------------------------------------------------------------------------------------------

    public class AgentBehaviorListClass : List<AgentBehaviorClass>
    {
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Findby code. </summary>
        ///
        /// <param name="aCode">    The code. </param>
        ///
        /// <returns>   The AgentBehaviorClass. </returns>
        ///-------------------------------------------------------------------------------------------------

        public AgentBehaviorClass FindbyCode(int aCode)
        {
            AgentBehaviorClass Temp = this.Find(delegate(AgentBehaviorClass AB) { return AB.BehaviorCode == aCode; });
            return Temp;
        }
    }

    #endregion AgentBehavior


    //=====================================================
    // Demand Agent Class
    // ====================================================
     
    /// <summary>   Demand agent. 
    ///             This is the base Demand Agent Class</summary>
    public class Agent
    {
		// Identifiers
        Guid FID;
        protected string FTypeCode = "";
        protected string FTypeLabel = "";
		protected string FName = "";
		// Demand Results
       
        AgentBehaviorListClass FBehaviorList = new AgentBehaviorListClass();

        /// <summary>   Default constructor. </summary>
		public Agent()
        {
            FID = Guid.NewGuid();
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="aTypeCode">    The type code. </param>
        /// <param name="aTypeLabel">   The type label. </param>
        ///-------------------------------------------------------------------------------------------------

        public Agent(string aTypeCode, string aTypeLabel)
        {
            FID = Guid.NewGuid();
            FTypeCode = aTypeCode;
            FTypeLabel = aTypeLabel;
			FName = FID.ToString("X");
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="aTypeCode">    The type code. </param>
        /// <param name="aTypeLabel">   The type label. </param>
        /// <param name="aName">        The name. This must be a unique name for all agents used</param>
        ///-------------------------------------------------------------------------------------------------

        public Agent(string aTypeCode, string aTypeLabel, string aName)
        {
            FID = Guid.NewGuid();
            FTypeCode = aTypeCode;
            FTypeLabel = aTypeLabel;
			FName = aName;
        }
        //==================================================================
        // Operation Methods
        // =================================================================

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Runs this object. </summary>
        /// 
        /// <remarks>   This is the core routine for each agent, any action to be done by an agent is done in this routine. </remarks>
        ///
        /// <returns>   true if it succeeds, false if it fails. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual bool Run()
        {
            bool result = false;

            result = true;
            return result;
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Recieve message
        ///             This method allows messages and data to be communicated between Agents. </summary>
        ///
        ///
        /// <param name="aDemandAgent"> The demand agent. </param>
        /// <param name="MessageCode">  The message code. </param>
        /// <param name="aValue">       The value being sent. </param>
        ///
        /// <returns>   An int. 0 means message is NOT acknowledged, >0 means message acknowledge</returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual int RecieveMessage(Agent SendingAgent, int MessageCode, string aMessage, double aValue)
        {
            int result = 0;
            // DO Soemthing
             
            // acknowledge message
            result = 1;

            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Sends a message. 
        ///             This method allows messages and data to be communicated between Agents. </summary>
        /// <param name="TargetAgent">  Target agent. </param>
        /// <param name="MessageCode">  The message code. </param>
        /// <param name="aMessage">     The message. </param>
        /// <param name="aValue">       The value being sent. </param>
        ///
        /// <returns>   An int. 0 means message is NOT acknowledged, >0 means message acknowledge</returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual int SendMessage(Agent TargetAgent, int MessageCode, string aMessage, double aValue)
        {
            return TargetAgent.RecieveMessage(this, MessageCode, aMessage, aValue);
        }


        public void AddBehavior(AgentBehaviorClass aBehavior)
        {
            BehaviorList.Add(aBehavior);
        }
        //====================================================================
        // Properties
        // ===================================================================

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the identifier. </summary>
        ///
        /// <value> The identifier. </value>
        ///-------------------------------------------------------------------------------------------------

        public Guid ID
        {
            get { return FID; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the type code. </summary>
        ///
        /// <value> The type code. </value>
        ///-------------------------------------------------------------------------------------------------

        public string TypeCode
        {
            get { return FTypeCode; }
            set { FTypeCode = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the type label. </summary>
        ///
        /// <value> The type label. </value>
        ///-------------------------------------------------------------------------------------------------

        public string TypeLabel
        {
            get { return FTypeLabel; }
            set { FTypeLabel = value; }
        }

		public string UniqueName
        {
			get { return FName; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets a list of behaviors. </summary>
        ///
        /// <value> A List of behaviors. </value>
        ///-------------------------------------------------------------------------------------------------

        public AgentBehaviorListClass BehaviorList
        {
            get { return FBehaviorList; }
        }



    }

	//=========================================================================================
    /// <summary>   Agent model. 
    ///             This is the base Model class, ie the playground for agents</summary>
    class AgentModel
    {
		// The Players, a list of agents
		List<Agent> FAgentList = new List<Agent>();

        /// <summary>   Default constructor. </summary>
        public AgentModel()
        {
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Adds a demand agent. </summary>
        ///
        /// <param name="TheAgent"> the agent. </param>
        ///-------------------------------------------------------------------------------------------------

		public void AddAgent(Agent TheAgent)
        {
			FAgentList.Add(TheAgent);
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Searches for the first agent with Unique ID
        ///
        /// <param name="UniqueName">   Name of the unique. </param>
        ///
        /// <returns>   The found agent. </returns>
        ///-------------------------------------------------------------------------------------------------

        public Agent FindAgent(string UniqueName)
        {
            Agent Temp = FAgentList.Find(delegate(Agent DA) { return DA.UniqueName == UniqueName; });
            return Temp;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Searches for the first agents. </summary>
        ///
        /// <param name="TypeCode"> The type code. </param>
        ///
        /// <returns>   The found agents. </returns>
        ///-------------------------------------------------------------------------------------------------

        public List<Agent> FindAgents(string TypeCode)
        {
            List<Agent> Temp = new List<Agent>();
            foreach (Agent DM in FAgentList)
            {
                if (DM.TypeCode == TypeCode)
                    Temp.Add(DM);
            }
            return Temp;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Executes the model operation. </summary>
        ///
        /// <returns>   0 ir no errors, >0 if errors. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual int RunModel()
        {
            int result = 0;
            try
            {
               foreach (Agent DM in FAgentList)
               {
                   DM.Run();
               }
            }
            catch (Exception ex)
            {
                result = 1;
            }
            return result;
        }

    }



}
