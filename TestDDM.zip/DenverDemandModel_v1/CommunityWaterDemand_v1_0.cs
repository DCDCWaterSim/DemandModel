﻿using System;
using System.Collections.Generic;


namespace   WaterDemandAgentClass
{
    ///-------------------------------------------------------------------------------------------------
    /// <summary>   Community water demand. </summary>
    ///
    /// <seealso cref="System.Collections.Generic.List<WaterDemandAgentClass.WaterDemandAgent>"/>
    ///-------------------------------------------------------------------------------------------------

    public class CommunityWaterDemand : List<WaterDemandAgent>
    {
        string FName = "";
        // Base
        double FTotalDemand = 0.0;
        double FTotalIndoor = 0.0;
        double FTotalOutdoor = 0.0;
        double FTotalProcess = 0.0;

        // Setup for Dynamic Output
        const int FFieldCount = 6;
        List<string> FFieldnames = new List<string>() { "SCN_Name", "TOTDEM", "INDEM", "OUTDEM", "PRCDEM", "TOTAGNT" };
        List<string> FFieldDescs = new List<string>() {"The name of the community scenario", 
                                                        "The total demand (outdoor, indoor, process) for all agents in community", 
                                                        "The total indoor demand for all agents in community",
                                                        "The total outdoor demand for all agents in community",
                                                        "The total process demand for all agents in community",
                                                        "Total Number of agents in this community"
                                                        };
        const int fiSCN_Name = 0;
        const int fiTOTDEM = 1;
        const int fiINDEM = 2;
        const int fiOUTDEM = 3;
        const int fiPRCDEM = 4;
        const int fiTOTAGNT = 5;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <param name="Name"> The name. </param>
        ///-------------------------------------------------------------------------------------------------

        public CommunityWaterDemand(string Name)
        {
            FName = Name;

        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the name. </summary>
        ///
        /// <value> The name. </value>
        ///-------------------------------------------------------------------------------------------------

        public string Name
        {
            get { return FName; }
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total indoor demand. </summary>
        ///
        /// <returns>   The total number of indoor demand. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual double TotalIndoorDemand()
        {
            //double result = 0;
            //foreach (WaterDemandAgent WDA in this)
            //{
            //    result += WDA.IndoorDemand;
            //}
            //return result;
            return FTotalIndoor;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total outdoor demand. </summary>
        ///
        /// <returns>   The total number of outdoor demand. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual double TotalOutdoorDemand()
        {
            //double result = 0;
            //foreach (WaterDemandAgent WDA in this)
            //{
            //    result += WDA.OutdoorDemand;
            //}
            //return result;
            return FTotalOutdoor; 
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total process demand. </summary>
        ///
        /// <returns>   The total number of process demand. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual double TotalProcessDemand()
        {
            //double result = 0;
            //foreach (WaterDemandAgent WDA in this)
            //{
            //    result += WDA.ProcessDemand;
            //}
            //return result;
            return FTotalProcess;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the total all demand. </summary>
        ///
        /// <returns>   The total number of all demand. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual double TotalAllDemand()
        {
            //double result = 0;
            //foreach (WaterDemandAgent WDA in this)
            //{
            //    result += WDA.TotalDemand;
            //}
            //return result;
            return FTotalDemand;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the number of agents. </summary>
        ///
        /// <value> The number of agents. </value>
        ///-------------------------------------------------------------------------------------------------

        public double AgentCount
        {
            get { return this.Count; }
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Searches for the first by name. </summary>
        /// <remarks>   Since name is required tro be unique for this list, the first should be the only</remarks>
        /// <param name="Name"> The name. </param>
        ///
        /// <returns>   The found by name. </returns>
        ///-------------------------------------------------------------------------------------------------

        public WaterDemandAgent FindByName(string Name)
        {
            return this.Find(delegate(WaterDemandAgent WDA) { return WDA.UniqueName == Name; });
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Searches for the first by identifier. </summary>
        /// <remarks>   Since ID is a unique system GUID value, the first should be the only</remarks>
        /// <param name="anID"> Identifier for an. </param>
        ///
        /// <returns>   The found by identifier. </returns>
        ///-------------------------------------------------------------------------------------------------

        public WaterDemandAgent FindByID(Guid anID)
        {
            return this.Find(delegate(WaterDemandAgent WDA) { return WDA.ID == anID; });
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Returns all the agents that match type code. </summary>
        ///
        /// <param name="aTypeCode">    The type code. </param>
        ///
        /// <returns>   List of agents. </returns>
        ///-------------------------------------------------------------------------------------------------

        public List<WaterDemandAgent> FindByTypeCode(string aTypeCode)
        {
            List<WaterDemandAgent> result = new List<WaterDemandAgent>();
            foreach (WaterDemandAgent WDA in this)
            {
                if (WDA.TypeCode == aTypeCode)
                {
                    result.Add(WDA);
                }
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Runs all the Agents. </summary>
        /// <remarks>   calls the Run() method for all agents, returns how many returned true, count of false can be
        ///             calculated by subtract this valei from Count</remarks>
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual int Run()
        {
            int result = 0;
            FTotalDemand = 0.0;
            FTotalIndoor = 0.0;
            FTotalOutdoor = 0.0;
            FTotalProcess = 0.0;

            foreach (WaterDemandAgent WDA in this)
            {
                bool temp = WDA.Run();
                if (temp)
                {
                    result++;
                }
                FTotalDemand += WDA.TotalDemand;
                FTotalIndoor += WDA.IndoorDemand;
                FTotalOutdoor += WDA.OutdoorDemand;
                FTotalProcess += WDA.ProcessDemand;
               
            }
            return result;
        }

        /// <summary>   Recalc metrics. </summary>
        public virtual void RecalcMetrics()
        {
            FTotalDemand = 0.0;
            FTotalIndoor = 0.0;
            FTotalOutdoor = 0.0;
            FTotalProcess = 0.0;
            foreach (WaterDemandAgent WDA in this)
            {
                    FTotalDemand += WDA.TotalDemand;
                    FTotalIndoor += WDA.IndoorDemand;
                    FTotalOutdoor += WDA.OutdoorDemand;
                    FTotalProcess += WDA.ProcessDemand;
            }

        }

        
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Broadcast message to all Agents. </summary>
        /// <remarks>   Sends to all agents, returns how many acknowledged message</remarks>
        /// <param name="MessageCode">  The message code. </param>
        /// <param name="aMessage">     The message. </param>
        /// <param name="aValue">       The value. </param>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public int BroadCastMessage(int MessageCode, string aMessage, double aValue)
        {
            int result = 0;
            foreach (WaterDemandAgent WDA in this)
            {
                result += WDA.RecieveMessage(null,MessageCode,aMessage,aValue);
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Converts a Format to a field header string. </summary>
        /// <param name="Format">   Describes the format to use. </param>
        /// <returns>   Format as a string. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual string ToFieldHeaderString(string Format)
        {
            string result = "SCN_Name";
            // Setup Formatting
            Format = Format.ToUpper();
            string Mark = GetMark(Format);
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }

            result += Mark+ "TOTDEM";
            result += Mark + "INDEM";
            result += Mark + "OUTDEM";
            result += Mark + "PRCDEM";
            result += Mark + "TOTAGNT";
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Converts this object to a field header string. </summary>
        /// <param name="Format">       Describes the format to use. </param>
        /// <param name="parameter2">   List of Fields to include. </param>
        ///
        /// <returns>   The given data converted to a string. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual string ToFieldHeaderString(string Format, List<string>UseFields)
        {
            string result = "";
            Format = Format.ToUpper();
            string Mark = GetMark(Format);
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }
            else
            {

                foreach (string fldname in UseFields)
                {
                    string AField = fldname.ToUpper();
                    switch (AField)
                    {
                        case "SCN_Name":
                            result += Mark + AField;
                            break;
                        case "TOTDEM":
                            result +=  Mark + AField;
                            break;
                        case "INDEM":
                            result +=  Mark + AField;
                            break;
                        case "OUTDEM":
                            result +=  Mark + AField;
                            break;
                        case "PRCDEM":
                            result += Mark + AField;
                            break;
                        case "TOTAGNT":
                            result += Mark + AField;
                            break;
                        
                    }
                }
            }                
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Converts an Indent to an xml define string. </summary>
        ///
        /// <param name="Indent">   The indent. </param>
        ///
        /// <returns>   Indent as a string. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual string ToXMLDefineString(string Indent)
        {
            string result = "";
            for (int i = 0; i < FFieldCount; i++)
            {
                result += XMLField(Indent, FFieldnames[i], FFieldDescs[i]);
            }

            //result += XMLField(Indent, "SCN_Name", "The name of the community scenario");
            //result += XMLField(Indent, "TOTDEM", "The total demand (outdoor, indoor, process) for all agents in community");
            //result += XMLField(Indent, "INDEM", "The total indoor demand for all agents in community");
            //result += XMLField(Indent, "OUTDEM", "The total outdoor demand for all agents in community");
            //result += XMLField(Indent, "PRCDEM", "The total process demand for all agents in community");
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Converts this object to an XML define string. </summary>
        /// <param name="Indent">       The indent. </param>
        /// <param name="UseFields">    The use fields. </param>
        ///
        /// <returns>   The given data converted to a string. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual string ToXMLDefineString(string Indent, List<string> UseFields)
        {
            string result = "";
                foreach (string fldname in UseFields)
                {
                    string AField = fldname.ToUpper();

                    for (int i = 0; i < FFieldCount; i++)
                    {
                        string test = FFieldnames[i].ToUpper();
                        if (test == AField)
                        {
                            result += XMLField(Indent, FFieldnames[i], FFieldDescs[i]);
                            break;
                        }
                    }
                }
            return result;
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Converts a value to a f. </summary>
        ///
        /// <param name="value">    The value. </param>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public  double ConvertToAF(double value)
        {
            return value / 328581;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Xml field. </summary>
        ///
        /// <param name="Indent">       The indent. </param>
        /// <param name="Name">         The name. </param>
        /// <param name="Definition">   The definition. </param>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        static public string XMLField(string Indent, string Name, string Definition)
        {
            string result = Indent + "<Field>" + Environment.NewLine;
            result += Indent + "   <FieldName>" + Name + "</FieldName>" + Environment.NewLine;
            result += Indent + "   <FieldDefine>" + Environment.NewLine;
            result += Indent + "      " + Definition + Environment.NewLine;
            result += Indent + "   </FieldDefine>" + Environment.NewLine;
            result += Indent + "</Field>" + Environment.NewLine;
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets a mark. </summary>
        ///
        /// <param name="Format">   Describes the format to use. </param>
        ///
        /// <returns>   The mark. </returns>
        ///-------------------------------------------------------------------------------------------------

        protected virtual string GetMark(string Format)
        {
            string Mark = "";
            // Setup Formatting
            Format = Format.ToUpper();
            switch (Format)
            {
                case "CSV":
                    Mark = ",";
                    break;
                case "TAB":
                    Mark = "/t";
                    break;
            }
            return Mark;
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Convert this object into a string representation. </summary>
        /// <param name="Format">   Describes the format to use. </param>
        /// <returns>   A string that represents this object. </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual string ToString(string Format)
        {
            string result = FName;
            // Setup Formatting
            string Mark = GetMark(Format);
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }
            else
            {
                // Do Base Values
                string DemandStr = ConvertToAF(TotalAllDemand()).ToString("F2");
                string IndoorStr = ConvertToAF(TotalIndoorDemand()).ToString("F2");
                string OutdoorStr = ConvertToAF(TotalOutdoorDemand()).ToString("F2");
                string ProcessStr = ConvertToAF(TotalProcessDemand()).ToString("F2");
                result += Mark + DemandStr + Mark + IndoorStr + Mark + OutdoorStr + Mark + ProcessStr;
            }

            return result;
        }
        public virtual string ToString(string Format, List<string> UseFields)
        {
            
            string result = FName;
            // Setup Formatting
            string Mark = GetMark(Format);
            if (Mark == "")
            {
                result = "Format: " + Format + " is not supported.";
            }
            else
            {
                foreach (string fldname in UseFields)
                {
                    string AField = fldname.ToUpper();
                    switch (AField)
                    {
                        case "SCN_Name":
                            break;
                        case "TOTDEM":
                            break;
                        case "INDEM":
                            break;
                        case "OUTDEM":
                            break;
                        case "PRCDEM":
                            break;
                        case "TOTAGNT":
                            break;

                    }
                }
            }
            return result;
        }


    }
 
}
