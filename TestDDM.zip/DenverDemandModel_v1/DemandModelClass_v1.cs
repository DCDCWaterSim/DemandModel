﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//===================================================================
// Denver Demand Model
// Version 1.0   3/3/17
// A model that estimates residential demand for different residential building types.
// Keeper:  Ray Quay 3/3/17
//          Decision Center for a Desert City
//          Arizona State University
// Based on the Pop_And_Product_Type_Model_DRAFT.xlms Excel weorkbook developed by Mitch Hollis from Denver Water 
// provide to DCDC on Feb 10th 2017
//
// Notes:
// Version 1
// The documentation here in refers to the cell ID for different cells.  In all cases, unless other wise specified, these cell references refer 
// to the Population & Product Type Model worksheet
//
// ===========================================================================

namespace DenverDemandModel_v1
{
    public class DemandModel
    {
        //Constants
        const double BADVALUE = double.NaN;
        const int FLandUseNumber = 7;

        // Inputs
        
        
        // Population
        double FTP_TotalPop = 0;           // B13       Total Population
        // POP by building type
        double[] FPopulation = new double[FLandUseNumber] { 0, 0, 0, 0, 0, 0, 0 };

        
        double FLSF_LargeSFUnits = 0;        // B14     Large Single Family 
        double FTSF_TypicalSFUnits = 0;      // B15     Typical Single Family
        double FSSF_SmallSFUnits = 0;        // B16     Small Single Family
        double FSMF_SmallMFUnits = 0;        // B17     Small Multifamily
        double FWMF_WalkupMFUnits = 0;       // B18     3 story Walkup Multifamily    
        double FMMF_MidRangeMFUnits = 0;     // B19     Mid-Range Multifamily
        double FHMF_HighDensityMFUnits = 0;  // B20     High Density Multifamily
       
        // Assumptions
        
        // Pervious Surface Equation Coefficients
        // Form "EQUATION" worksheet
        // Persons Per Household
        double[] FPersonPerHH = new double[FLandUseNumber] { 2.5, 2.5, 2.4, 2.4, 2.3, 2.1, 2.0 };  // defaults

        double FPPH_LSF = 2.5;      // G14      Large Single Family
        double FPPH_TSF = 2.5;      // G15      Typical Single Family
        double FPPH_SSF = 2.4;      // G16      Small Single Family
        double FPPH_SMF = 2.4;      // G17      Small Multi Family
        double FPPH_WMF = 2.3;      // G18      3 Story Walkup Multifamily
        double FPPH_MMF = 2.1;      // G19      Mid Range Multifamily
        double FPPH_HMF = 2.0;      // G20      High Density Multifamily

        //  Indoor GPCD
        double[] FIndoorGPCD = new double[FLandUseNumber] { 50, 50, 50, 50, 50, 50, 50 }; // defaults
        
        double FINGPCD_LSF = 50;    // H14      Large Single Family
        double FINGPCD_TSF = 50;    // H15      Typical Single Family
        double FINGPCD_SSF = 50;    // H16      Small Single Family
        double FINGPCD_SMF = 50;    // H17      Small Multi Family
        double FINGPCD_WMF = 50;    // H18      3 Story Walkup Multifamily
        double FINGPCD_MMF = 50;    // H19      Mid Range Multifamily
        double FINGPCD_HMF = 50;    // H20      High Density Multifamily

        // Dwelling Units Per Acre
        double[] FDUA = new double[FLandUseNumber] { 5,7,10,14,20,35,60 };  // Defaults
        
        double FDUA_LSF = 5;        // I14      Large Single Family
        double FDUA_TSF = 7;        // I15      Typical Single Family
        double FDUA_SSF = 10;       // I16      Small Single Family
        double FDUA_SMF = 14;       // I17      Small Multi Family
        double FDUA_WMF = 20;       // I18      3 Story Walkup Multifamily
        double FDUA_MMF = 35;       // I19      Mid Range Multifamily
        double FDUA_HMF = 60;       // I20      High Density Multifamily

        //  Seasonal Gallons Per Square Foot of pervious surface
        double[] FGallonsPerSqFt = new double[FLandUseNumber] { 16, 12, 10, 14, 15, 18, 30 }; // Defaults
        
        double FGPSF_LSF = 16;      // J14      Large Single Family
        double FGPSF_TSF = 12;      // J15      Typical Single Family
        double FGPSF_SSF = 10;      // J16      Small Single Family
        double FGPSF_SMF = 14;      // J17      Small Multi Family
        double FGPSF_WMF = 15;      // J18      3 Story Walkup Multifamily
        double FGPSF_MMF = 18;      // J19      Mid Range Multifamily
        double FGPSF_HMF = 30;      // J20      High Density Multifamily

        public DemandModel()
        {

        }

        //===========================================================================================
        // Derived factors.
        //===========================================================================================
        #region Derived Factors


        // ===========================================================================================
        // Estimated Acres Factors.
        //  
        #region Estimated Acres

        // These are Derived from Cell B31   =((B14/$G14)/$I14)+((B15/$G15)/$I15)+((B16/$G16)/$I16)+((B17/$G17)/$I17)+((B18/$G18)/$I18)+((B19/$G19)/$I19)+((B20/$G20)/$I20)
        //=============================================================================================       

        public double[] EstimatedAcres()
        {
            // create array
            double[] result = new double[FLandUseNumber];
            // loop through landuses
            for (int i = 0; i < FLandUseNumber; i++)
            {
                // check if factors not 0
                if ((FPersonPerHH[i] > 0) && (FDUA[i] > 0))
                {
                    // calculate Acres
                    result[i] = FPopulation[i] / FPersonPerHH[i] / FDUA[i];
                }
                else
                // if either = 0  set to BADVALUE
                {
                    result[i] = BADVALUE;
                }
            }
            return result;
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimated acres lsf. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double EstimatedAcres_LSF()          //  Large Single Family
        {
            // =((B14/$G14)/$I14)
            double result = BADVALUE;
            if ((FPPH_LSF > 0) && (FDUA_LSF > 0))
            {
                result = FLSF_LargeSFUnits / FPPH_LSF / FDUA_LSF;
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimated acres tsf. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double EstimatedAcres_TSF()      //  Typical Single Family
        {
            // =((B15/$G15)/$I15)
            double result = BADVALUE;
            if ((FPPH_TSF > 0) && (FDUA_TSF > 0))
            {
                result = FTSF_TypicalSFUnits / FPPH_TSF / FDUA_TSF;
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimated acres ssf. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double EstimatedAcres_SSF()      //  Small Single Family
        {
            // =((B16/$G16)/$I16)
            double result = BADVALUE;
            if ((FPPH_SSF > 0) && (FDUA_SSF > 0))
            {
                result = FSSF_SmallSFUnits / FPPH_SSF / FDUA_SSF;
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimated acres smf. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double EstimatedAcres_SMF()      //  Small Multi Family
        {
            // =((B17/$G17)/$I17)
            double result = BADVALUE;
            if ((FPPH_SMF > 0) && (FDUA_SMF > 0))
            {
                result = FSMF_SmallMFUnits / FPPH_SMF / FDUA_SMF;
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimated acres wmf. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double EstimatedAcres_WMF()     //  3 Story Walkup Multifamily
        {
            // =((B18/$G18)/$I18)
            double result = BADVALUE;
            if ((FPPH_WMF > 0) && (FDUA_WMF > 0))
            {
                result = FWMF_WalkupMFUnits / FPPH_WMF / FDUA_WMF;
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimated acres mmf. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double EstimatedAcres_MMF()     //  Mid Range Multifamily
        {
            // =((B19/$G19)/$I19)
            double result = BADVALUE;
            if ((FPPH_MMF > 0) && (FDUA_MMF > 0))
            {
                result = FMMF_MidRangeMFUnits / FPPH_MMF / FDUA_MMF;
            }
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimated acres hmf. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public double EstimatedAcres_HMF()      //  High Density Multifamily
        {
            // =((B20/$G20)/$I20)
            double result = BADVALUE;
            if ((FPPH_HMF > 0) && (FDUA_HMF > 0))
            {
                result = FHMF_HighDensityMFUnits / FPPH_HMF / FDUA_HMF;
            }
            return result;
        }

        #endregion Estimated Acres

        //==================================================================
        // Estimated Pervious Area     
        //    
            
        #region Estimated Pervious Area

        //  These are derived from cell B32
        //  
        //  =IFERROR(Equation!$B$1*($I14^Equation!$B$2)*(B14/$G14)/43560,0)+IFERROR(Equation!$B$1*($I15^Equation!$B$2)*(B15/$G15)/43560,0)+IFERROR(Equation!$B$1*($I16^Equation!$B$2)*(B16/$G16)/43560,0)+IFERROR(Equation!$B$1*($I17^Equation!$B$2)*(B17/$G17)/43560,0)+IFERROR(Equation!$B$1*($I18^Equation!$B$2)*(B18/$G18)/43560,0)+IFERROR(Equation!$B$1*($I19^Equation!$B$2)*(B19/$G19)/43560,0)+IFERROR(Equation!$B$1*($I20^Equation!$B$2)*(B20/$G20)/43560,0)
        //==================================================================

        

        //==================================================================

        #endregion Estimated Pervious Area

        #endregion Derived Factors

    }
}
