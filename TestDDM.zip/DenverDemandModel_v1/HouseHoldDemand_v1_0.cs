﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AgentClasses;
using BuildingTypes;

namespace WaterDemandAgentClass
{
    ///-------------------------------------------------------------------------------------------------
    /// <summary>   House hold water demand. </summary>
    ///
    /// <seealso cref="WaterDemandAgentClass.WaterDemandAgent"/>
    ///-------------------------------------------------------------------------------------------------

    public class HouseHoldWaterDemand : WaterDemandAgent
    {
        BuildingType FBuildType = null;
        double FPPHH = 0.0;
        double FHHNumber = 0.0;
        double FIndoorGPCD = 0.0;
        double FDUA = 0.0;
        double FPerviousSqFtPerUnit = 0.0;
        double FGallonsPerSqFt = 0.0;

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <remarks>   This creates a household using the data from the BuildType . </remarks>
        ///
        /// <param name="aTypeCode">            The type code. </param>
        /// <param name="aTypeLabel">           The type label. </param>
        /// <param name="aNamestring">          The namestring. </param>
        /// <param name="aBuildType">           Type of the build. </param>
        /// <param name="aPersonsPerHousholds"> The persons per housholds. </param>
        /// <param name="HouseHoldNumber">      The house hold number. </param>
        /// <param name="TheIndoorGPCD">        the indoor gpcd. </param>
        ///
        /// ### <param name="TheGPCD">  the gpcd. </param>
        ///-------------------------------------------------------------------------------------------------

        public HouseHoldWaterDemand(string aTypeCode, string aTypeLabel, string aNamestring, BuildingType aBuildType, double aPersonsPerHousholds, double HouseHoldNumber, double TheIndoorGPCD): 
            base(aTypeCode,aTypeLabel,aNamestring)
        {
            BuildType = aBuildType;
            FPPHH = aPersonsPerHousholds;
            FHHNumber = HouseHoldNumber;
            FIndoorGPCD = TheIndoorGPCD;
            // These already set up with BuildType set
            //FPerviousSqFtPerUnit = FBuildType.EstimatedPerviousSqFtPerDwellingUnit();
            //FGallonsPerSqFt = FBuildType.GallonsPerSqFtPervious;
            //FDUA = FBuildType.DwellinUnitsPerAcre;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Constructor. </summary>
        ///
        /// <remarks>   This creates a household using the data passed rather than a BuildType . </remarks>
        ///
        /// <param name="aTypeCode">            The type code. </param>
        /// <param name="aTypeLabel">           The type label. </param>
        /// <param name="aNamestring">          The namestring. </param>
        /// <param name="aPersonsPerHousholds"> The persons per housholds. </param>
        /// <param name="HouseHoldNumber">      The house hold number. </param>
        /// <param name="TheIndoorGPCD">        the indoor gpcd. </param>
        /// <param name="PerviousPerUnit">      The pervious per unit. </param>
        /// <param name="GallonsPerSqFt">       The gallons per sq ft. </param>
        /// <param name="DwellingUnitsPerAcre"> The dwelling units per acre. </param>
        ///-------------------------------------------------------------------------------------------------

        public HouseHoldWaterDemand(string aTypeCode, string aTypeLabel, string aNamestring, double aPersonsPerHousholds, double HouseHoldNumber, double TheIndoorGPCD, double PerviousPerUnit, double GallonsPerSqFt, double DwellingUnitsPerAcre):
            base(aTypeCode, aTypeLabel, aNamestring)
        {
            FBuildType = null;
            FPPHH = aPersonsPerHousholds;
            FHHNumber = HouseHoldNumber;
            FIndoorGPCD = TheIndoorGPCD;
            FPerviousSqFtPerUnit = PerviousPerUnit;
            FGallonsPerSqFt = GallonsPerSqFt;
            FDUA = DwellingUnitsPerAcre;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the type of the build. </summary>
        ///
        /// <value> The type of the build. </value>
        ///-------------------------------------------------------------------------------------------------

        public BuildingType BuildType
        {
            get { return FBuildType; }
            set 
            { 
                FBuildType = value;
                FPerviousSqFtPerUnit = FBuildType.EstimatedPerviousSqFtPerDwellingUnit();
                FGallonsPerSqFt = FBuildType.GallonsPerSqFtPervious;
                FDUA = FBuildType.DwellinUnitsPerAcre;
            }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the size of the house hold. </summary>
        ///
        /// <value> The size of the house hold. </value>
        ///-------------------------------------------------------------------------------------------------

        public double HouseHoldSize
        {
            get { return FPPHH; }
            set { FPPHH = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets or sets the number of households. </summary>
        ///
        /// <value> The total number of households. </value>
        ///-------------------------------------------------------------------------------------------------

        public double NumberOfHouseholds
        {
            get { return FHHNumber; }
            set { FHHNumber = value; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the pervious sq ft. </summary>
        ///
        /// <value> The pervious sq ft. </value>
        ///-------------------------------------------------------------------------------------------------

        public double PerviousSqFt
        {
            get { return FPerviousSqFtPerUnit * FHHNumber; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the outdoor gallons per sq ft. </summary>
        ///
        /// <value> The outdoor gallons per sq ft. </value>
        ///-------------------------------------------------------------------------------------------------

        public double OutdoorGallonsPerSqFt
        {
            get { return FGallonsPerSqFt; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average gpcd. </summary>
        ///
        /// <value> The average gpcd. </value>
        ///-------------------------------------------------------------------------------------------------

        public double AverageGPCD
        {
            get { return TotalDemand / FPPHH / 365; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average annual demand per unit. </summary>
        ///
        /// <value> The average annual demand per unit. </value>
        ///-------------------------------------------------------------------------------------------------

        public double AverageAnnualDemandPerUnit
        {
            get { return TotalDemand / FHHNumber; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the developed acres. </summary>
        ///
        /// <value> The developed acres. </value>
        ///-------------------------------------------------------------------------------------------------

        public double DevelopedAcres
        {
            get { return FHHNumber / FDUA; }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gallons to acre feet. </summary>
        ///
        /// <param name="Gallons">  The gallons. </param>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        private double GallonsToAcreFeet(double Gallons)
        {
            return Gallons /  325851;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the average annual acre feet per acre. </summary>
        ///
        /// <value> The average annual acre feet per acre. </value>
        ///-------------------------------------------------------------------------------------------------

        public double AverageAnnualAcreFeetPerAcre
        {
            get { return GallonsToAcreFeet(TotalDemand / DevelopedAcres); }
        }
        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Estimate demand. </summary>
        ///
        /// <seealso cref="WaterDemandAgentClass.WaterDemandAgent.EstimateDemand()"/>
        ///-------------------------------------------------------------------------------------------------

        public override void EstimateDemand()
        {
            FIndoorDemand = EstimateIndoorDemand();
            FOutdoorDemand = EstimateOutdoorDemand();
            base.EstimateDemand();
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimate indoor demand. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual double EstimateIndoorDemand()
        {
            double result = 0;
            double people = FHHNumber * FPPHH;
            result = people * FIndoorGPCD * 365;
            return result;
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>   Gets the estimate outdoor demand. </summary>
        ///
        /// <returns>   . </returns>
        ///-------------------------------------------------------------------------------------------------

        public virtual double EstimateOutdoorDemand()
        {
            double result = 0;
            //double PerviousSqFt = FBuildType.EstimatedPerviousSqFtPerDwellingUnit();
            //double GallonsSqFt = FBuildType.GallonsPerSqFtPervious;
            //double TotalPerviousArea = FHHNumber * PerviousSqFt;
            //result = TotalPerviousArea * GallonsSqFt;
            double TotalPerviousArea = PerviousSqFt;
            result = TotalPerviousArea * FGallonsPerSqFt;
            
            return result;
        }
    }
}
